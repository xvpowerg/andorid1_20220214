package com.howard11.ch6_1_20220225_kotlinoo4_java.testinterface;
@FunctionalInterface
public interface OnClickListener {
      public abstract void click(String msg);
}
