package com.howard11.ch6_1_20220225_kotlinoo4_java.testabstract;

import android.util.Log;

public abstract class Animal {
    private String name;
    private int age;

   public Animal(String name,int age){
       this.name = name;
        this.age = age;
    }
//提醒開發人員 複寫這個方法
    public abstract  void  bark();
    public int getAge(){
        return age;
    }
    public String getName(){
        return name;
    }
// 可將物件變字串
    public String toString(){
        return this.getName()+":"+this.getAge();
    }
}
