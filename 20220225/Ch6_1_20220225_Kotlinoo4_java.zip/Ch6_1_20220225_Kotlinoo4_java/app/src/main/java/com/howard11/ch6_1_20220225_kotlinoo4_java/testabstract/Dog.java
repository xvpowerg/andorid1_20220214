package com.howard11.ch6_1_20220225_kotlinoo4_java.testabstract;

import android.util.Log;

public class Dog extends Animal{
    public Dog(String name,int age){
        super(name,age);
    }
    public void bark(){
        Log.d("Howard","汪汪!");
    }
}
