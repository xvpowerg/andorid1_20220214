package com.howard11.ch6_1_20220225_kotlinoo4_java.testinterface;

public class CheckBox {
    private String msg;
    public CheckBox(String msg){
        this.msg = msg;
    }
    public void setOnClick(OnClickListener action){
        action.click(msg);
    }

    public void setOnLongClick(OnLongClick action){
        if (msg == null || msg.isEmpty()){
            action.empty("CheckBox訊息空白");
        }else{
            action.longClick(msg);
        }


    }
}
