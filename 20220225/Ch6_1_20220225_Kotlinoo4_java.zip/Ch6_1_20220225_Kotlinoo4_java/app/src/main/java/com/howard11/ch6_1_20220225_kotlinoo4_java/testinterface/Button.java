package com.howard11.ch6_1_20220225_kotlinoo4_java.testinterface;

public class Button {
    private String msg;
    public Button(String msg){
        this.msg = msg;
    }
    public void setOnclick(OnClickListener action){
        action.click(msg);
    }

    public void setOnLongClick(OnLongClick action){
        if (msg == null || msg.isEmpty() ){
            action.empty("Button訊息空白");
        }else{
            action.longClick(msg);
        }

    }

}
