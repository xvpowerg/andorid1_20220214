package com.howard11.ch6_1_20220225_kotlinoo4_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;


import com.howard11.ch6_1_20220225_kotlinoo4_java.testabstract.Animal;
import com.howard11.ch6_1_20220225_kotlinoo4_java.testabstract.Dog;
import com.howard11.ch6_1_20220225_kotlinoo4_java.testinterface.Button;
import com.howard11.ch6_1_20220225_kotlinoo4_java.testinterface.CheckBox;
import com.howard11.ch6_1_20220225_kotlinoo4_java.testinterface.MyClickClass;
import com.howard11.ch6_1_20220225_kotlinoo4_java.testinterface.OnClickListener;
import com.howard11.ch6_1_20220225_kotlinoo4_java.testinterface.OnLongClick;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
        private class MyOnLongClick implements OnLongClick {
                public void longClick(String msg){
                    Log.d("Howard","longClick msg:"+msg);
                }
                public void empty(String msg){
                    Log.d("Howard","empty msg:"+msg);
                }
        }
        private void checkBoxClick(String msg){
            Random random = new Random();
            int count = random.nextInt(1000);
            int[] array= new int[count];
            for (int i=0;i<count;i++){
                array[i] = random.nextInt(1000);
            }
            Log.d("Howard","array len:"+array.length);
        }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Animal dog1 = new Dog("Momo",28);
        Log.d("Howard","Dog1:"+dog1);
        dog1.bark();

        MyClickClass myClickClass = new MyClickClass();

        MyOnLongClick  onLongClick = new MyOnLongClick();
        Button btn = new Button("Button送出成績");
        btn.setOnclick(myClickClass);
        btn.setOnLongClick(onLongClick);

        CheckBox cbox = new CheckBox("CheckBox送出成績");
        cbox.setOnClick(myClickClass);
        cbox.setOnLongClick(onLongClick);

        Button btn2 = new Button("");
        btn2.setOnLongClick(onLongClick);

        Button btn3 = new Button("btn3送出資料");
        btn3.setOnclick(new OnClickListener(){
                public void click(String msg){
                        Log.d("Howard","msg:"+msg);
                    Toast.makeText(MainActivity.this,
                            msg,Toast.LENGTH_SHORT).show();
                }
        });

        btn3.setOnclick((String m1)->{
            Log.d("Howard","m1:"+m1);
                }
                );
        //因為只有一個參數不用()
        //因為只有一個執行命另不用{}與;
        btn3.setOnclick(m1->
                Toast.makeText(this,m1,Toast.LENGTH_LONG));

        CheckBox cbox2 = new CheckBox("Cbox2送出資料");
        //method reference
        cbox2.setOnClick(this::checkBoxClick);
        //CheckBox
        // 使用lambda 實作OnClickListener並呼叫 CheckBox的 setOnclick
        // 使用內部類 實作 OnLongClick 並呼叫 CheckBox的setOnLongClick
        CheckBox cbox3 = new CheckBox("");
        cbox3.setOnClick(m->{
            Log.d("Howard","msg:"+m);
        });

        cbox3.setOnLongClick(new OnLongClick(){
            public void longClick(String msg){
                Log.d("Howard","LongCLick msg:"+msg);
            }
            public void empty(String msg){
                Log.d("Howard","Empty msg:"+msg);
            }
        });
    }
}