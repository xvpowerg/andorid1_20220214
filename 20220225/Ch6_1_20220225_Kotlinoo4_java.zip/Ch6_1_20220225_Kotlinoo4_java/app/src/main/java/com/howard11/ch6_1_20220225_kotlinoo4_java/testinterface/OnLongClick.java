package com.howard11.ch6_1_20220225_kotlinoo4_java.testinterface;

public interface OnLongClick {

    void longClick(String msg);
    void empty(String msg);
}
