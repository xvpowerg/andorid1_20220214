package com.howard11.ch6_1_20220225_kotlinoo4_java.testinterface;

import android.util.Log;

public class MyClickClass implements OnClickListener{
    public void click(String msg){
        Log.d("Howard","msg:"+msg);
    }
}
