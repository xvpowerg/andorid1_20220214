package com.howard11.ch6_2_java_collection;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private  void testList(){
        ArrayList<Integer> list = new ArrayList();
        list.add(10);
        list.add(25);
        list.add(6);
        list.add(2);
        list.add(100);
        list.forEach((Integer v)-> Log.d("Howard","v:"+v));
        list.remove(Integer.valueOf(6));
        Log.d("Howard","==========================");
        list.forEach((Integer v)-> Log.d("Howard","v:"+v));

        int index = list.indexOf(25);
        Log.d("Howard","index:"+index);
        index = list.indexOf(6);
        Log.d("Howard","index:"+index);
        boolean b1 = list.contains(25);
        Log.d("Howard","find:"+b1);
        b1 = list.contains(6);
        Log.d("Howard","find:"+b1);

        list.replaceAll(v-> v > 10 ?v+2:v);
        list.forEach((Integer v)-> Log.d("Howard","v:"+v));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        testList();
    }
}