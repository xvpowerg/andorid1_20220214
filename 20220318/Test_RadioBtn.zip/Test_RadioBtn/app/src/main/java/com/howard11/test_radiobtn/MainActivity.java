package com.howard11.test_radiobtn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private HashMap<Integer,RadioButton> radioBtnMap = new HashMap<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RadioGroup rg = findViewById(R.id.rg);
        RadioButton rb1 =  findViewById(R.id.rb1);
        RadioButton rb2 =  findViewById(R.id.rb2);
        RadioButton rb3 =  findViewById(R.id.rb3);
        Button submit = findViewById(R.id.submit);
        radioBtnMap.put(R.id.rb1,rb1);
        radioBtnMap.put(R.id.rb2,rb2);
        radioBtnMap.put(R.id.rb3,rb3);
        StringBuffer sb = new StringBuffer();
        sb.append("請選擇狀態");
        rg.setOnCheckedChangeListener((tmpRg,isCheckId)->{
//            Log.d("Howard","rg:"+tmpRg.getId()+":"+isCheckId);
            RadioButton rb = radioBtnMap.get(isCheckId);
            Log.d("Howard","Text:"+rb.getText());
            sb.setLength(0);
            sb.append(rb.getText());
        });
        submit.setOnClickListener(v->{
            Log.d("Howard","sb:"+sb);

        });
    }
}