package com.howard11.test_checkbox1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class MainActivity extends AppCompatActivity {
    private void delCheckBoxMsg(StringBuilder msg,String key){
        int index = msg.indexOf(key);
       if (index < 0){
        return;
       }
       Log.d("Howard",index+":"+(key.length()+1));
        msg.delete(index,index+key.length()+1);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button submitBtn =  findViewById(R.id.submitBtn);
        CheckBox appleCBox =  findViewById(R.id.cb1);
        CheckBox bananaCBox =   findViewById(R.id.cb2);
        CheckBox kiwiCBox = findViewById(R.id.cb3);
        StringBuilder sb = new StringBuilder();
        appleCBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckBox tmpC = (CheckBox)v;
                String msg = tmpC.getText().toString();
                if (tmpC.isChecked()){
                    sb.append(msg+" ");
                  //  Log.d("Howard",msg);
                }else{
                    delCheckBoxMsg(sb,msg);
                }
            }
        });

        bananaCBox.setOnClickListener(v->{
            CheckBox tmpC = (CheckBox)v;
            String msg = tmpC.getText().toString();
            if (tmpC.isChecked()){
                sb.append(msg+" ");
                //Log.d("Howard","msg:"+msg);
            }else{
                delCheckBoxMsg(sb,msg);
            }
        });
        kiwiCBox.setOnClickListener(v->{
            String msg =  ((CheckBox) v).getText().toString();
            if (((CheckBox)v).isChecked() ){

                //Log.d("Howard",msg);
                sb.append(msg+" ");
            }else{
                delCheckBoxMsg(sb,msg);
            }
        });
        submitBtn.setOnClickListener(v->{

            Log.d("Howard","msg:"+sb);
        });
    }
}