package com.howard11.test_checkbox3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CheckBox;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<CheckBox> list = new ArrayList<>();
        CheckBox alllCbox =  findViewById(R.id.allCbox);
        CheckBox b1 = findViewById(R.id.cbox1);
        CheckBox b2 = findViewById(R.id.cbox2);
        CheckBox b3 = findViewById(R.id.cbox3);
        CheckBox b4 = findViewById(R.id.cbox4);
        CheckBox b5 = findViewById(R.id.cbox5);
        list.add(b1);
        list.add(b2);
        list.add(b3);
        list.add(b4);
        list.add(b5);
        alllCbox.setOnClickListener((v)->{
            CheckBox checkBox = (CheckBox)v;
            boolean isChecked = checkBox.isChecked();
            for (CheckBox cb : list){
                cb.setChecked(isChecked);
            }

        });
        alllCbox.setOnCheckedChangeListener((c,isChecked)->{
            list.forEach(v->v.setChecked(isChecked));

        });
        for (CheckBox tcb : list){
            tcb.setOnClickListener((v)->{

                boolean isChecked =
                        list.stream().allMatch(checkBox -> checkBox.isChecked());
                alllCbox.setChecked(isChecked);

            });
        }




    }
}