package com.howard11.test_checkbox2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {
    private ArrayList<String> list = new ArrayList<>();
    public void onCheckedChangeListener(CompoundButton cn,
                                        boolean isChecked){
        String cTxt = cn.getText().toString();
            if (isChecked){
                list.add(cTxt);
                Log.d("Howard","勾選isChecked:"+isChecked);
            }else{
                list.remove(cTxt);
                Log.d("Howard","取消勾選isChecked:"+isChecked);
            }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<CheckBox> cbList = new ArrayList<>();
        CheckBox cbox1 = findViewById(R.id.cb1);
        CheckBox cbox2 = findViewById(R.id.cb2);
        CheckBox cbox3 = findViewById(R.id.cb3);
        cbList.add(cbox1);
        cbList.add(cbox2);
        cbList.add(cbox3);

        Button btn = findViewById(R.id.submitBtn);
//        cbox1.setOnCheckedChangeListener((cb,isChecked)->{
//                if (isChecked){
//                    Log.d("Howard","勾選isChecked:"+isChecked);
//                }else{
//                    Log.d("Howard","取消勾選isChecked:"+isChecked);
//                }
//
//        });
//        cbox1.setOnCheckedChangeListener(this::onCheckedChangeListener);
//        cbox2.setOnCheckedChangeListener(this::onCheckedChangeListener);
//        cbox3.setOnCheckedChangeListener(this::onCheckedChangeListener);
        cbList.forEach(
                c->c.setOnCheckedChangeListener(this::onCheckedChangeListener));
        btn.setOnClickListener(v->{

            String msg = list.stream().collect(Collectors.joining(","));
            if(msg.isEmpty()){
                Toast.makeText(this, "請選擇某個選項", Toast.LENGTH_SHORT).show();
            }else{
                Log.d("Howard",msg);
            }

        });
    }
}