package com.howard11.test_order_system.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
public class Order implements Parcelable {


    public Order(){

    }
    private Order(Parcel parcel){
        items = parcel.createTypedArrayList(Item.CREATOR);
        category = Category.valueOf(parcel.readString());
    }
    private ArrayList<Item> items = new ArrayList<>();
    private Category category;
    private int total = 0;
    public enum Category{
        Internal,
        Takeout
    }
    public static final Creator<Order> CREATOR = new Creator<Order>() {
        @Override
        public Order createFromParcel(Parcel source) {
            return new Order(source);
        }

        @Override
        public Order[] newArray(int size) {
            return new Order[size];
        }
    };

    public Category getCategory() {
        return category;
    }
    public void setCategory(Category category) {
        this.category = category;
    }

    public void addItem(Item item){
        items.add(item);
    }

    public void readItems(Consumer<Item> consumer){
        for (Item it : items){
            consumer.accept(it);
        }
    }

    public int total(){
        readItems(item -> {
            total += item.getCount() * item.getPrice();
        });
        return  total;
    }
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(items);
        dest.writeString(category.name());
    }
}
