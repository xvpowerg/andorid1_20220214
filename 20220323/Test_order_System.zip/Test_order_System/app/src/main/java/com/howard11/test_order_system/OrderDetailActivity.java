package com.howard11.test_order_system;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.howard11.test_order_system.bean.Order;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class OrderDetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_detail_layout);
        ArrayList<String> list = new ArrayList<>();
        Intent data  = getIntent();
        Order order = data.getParcelableExtra("order");
       EditText orderText =  findViewById(R.id.orderDetailTxt);
        //orderText.setText();
        order.readItems(item->{
            list.add("item:"+item.toString());
        });
        String cat =
                (order.getCategory()==Order.Category.Internal)?"內用":"外帶";
        list.add("訂單類型:"+cat);
        list.add("總金額:"+order.total());
        String msg  = list.stream().collect(Collectors.joining("\n"));
        orderText.setText(msg);
       // Log.d("Howard","order:"+order.getCategory());
    }
}
