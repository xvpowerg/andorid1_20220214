package com.howard11.test_order_system.bean;

import android.os.Parcel;
import android.os.Parcelable;

public class Item  implements Parcelable {
    private String name;
    private int count;
    private int price;

    public Item(){

    }
    private Item(Parcel in){
            name = in.readString();
            count = in.readInt();
            price = in.readInt();
    }

    public Item(String name, int count, int price) {
        this.name = name;
        this.count = count;
        this.price = price;
    }
    public static final Creator<Item> CREATOR = new Creator<Item>() {
        @Override
        public Item createFromParcel(Parcel source) {
            return new Item(source);
        }

        @Override
        public Item[] newArray(int size) {
            return new Item[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(name);
        parcel.writeInt(count);
        parcel.writeInt(price);

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Item{" +
                "name='" + name + '\'' +
                ", count=" + count +
                ", price=" + price +
                '}';
    }
}
