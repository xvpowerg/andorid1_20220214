package com.howard11.test_order_system.verify;

public class VerifyMsg {
    private String msg;

    public VerifyMsg(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

    @Override
    public String toString() {
        return "VerifyMsg{" +
                "msg='" + msg + '\'' +
                '}';
    }
}
