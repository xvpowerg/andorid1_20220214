package com.howard11.test_order_system;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.howard11.test_order_system.bean.Item;
import com.howard11.test_order_system.bean.Order;
import com.howard11.test_order_system.verify.VerifyMsg;
import com.howard11.test_order_system.verify.VerifyOrder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {
   private ArrayList<CheckBox> cboxList = new ArrayList();
   private ArrayList<VerifyMsg> verifyMsgs = new ArrayList<>();
   private EditText[] countEditText = new EditText[3];
    private  String[] items;
    private  int[] prices;
    private Order order = new Order();

    private void initCheckBox(){
       CheckBox checkBox1  = findViewById(R.id.item1Cbox);
       CheckBox checkBox2  =  findViewById(R.id.item2Cbox);
       CheckBox checkBox3  = findViewById(R.id.item3Cbox);
       cboxList.add(checkBox1);
       cboxList.add(checkBox2);
       cboxList.add(checkBox3);
            
       items =  getResources().getStringArray(R.array.items);
       prices = getResources().getIntArray(R.array.price);

       
       for (int i = 0; i < cboxList.size();i++){
           CheckBox tmpCb = cboxList.get(i);
           String item = items[i];
           int price = prices[i];
           tmpCb.setText(item+" "+price);
       }
   }
   private void initRadioButton(){
       //設定為外帶
       RadioGroup trg = findViewById(R.id.takeTypeRG);
       RadioButton takeTB1 =  findViewById(R.id.takeRB1);

       trg.setOnCheckedChangeListener((rb,id)->{
                switch (id){
                    case  R.id.takeRB1:
                        order.setCategory(Order.Category.Takeout);
                        //Log.d("Howard","外帶");
                        break;
                    case R.id.takeRB2:
                        order.setCategory(Order.Category.Internal);
                       // Log.d("Howard","內用");
                        break;

                }

       });

       takeTB1.setChecked(true);

   }


   private void initCountEditText(){
       countEditText[0] = findViewById(R.id.item1CountTxt);
       countEditText[1] = findViewById(R.id.item2CountTxt);
       countEditText[2] = findViewById(R.id.item3CountTxt);
   }

   private boolean showErrorMsg(List<VerifyMsg> verifyMsgs){
            for (VerifyMsg vm : verifyMsgs){
                Log.e("Howard","vm:"+vm);
            }
            return !verifyMsgs.isEmpty();
   }


   private void clearErrorMsg(){
       verifyMsgs.clear();
   }
   private void initSubmitData(){
       clearErrorMsg();
       for (int i = 0; i < cboxList.size();i++){
           if (cboxList.get(i).isChecked()){
               EditText countEdx =  countEditText[i];
               if (!VerifyOrder.verifyOrderCount(
                       countEdx.getText().toString(),
                       cboxList.get(i),
                       verifyMsgs)){
                   continue;
               }
               int count = Integer.parseInt(countEdx.getText().toString());
               String item = items[i];
               int price = prices[i];
               Item itemObj = new Item(item,
                       count,price);
               order.addItem(itemObj);
               Log.d("Howard","item:"+itemObj);
           }
       }
   }
   private void initSubmitBtn(){
       Button submitBtn = findViewById(R.id.submitBtn);
       submitBtn.setOnClickListener(v->{
           initSubmitData();
           showErrorMsg(verifyMsgs);
           if (verifyMsgs.isEmpty()){
               Intent toDetail = new Intent(this,
                       OrderDetailActivity.class);
               toDetail.putExtra("order",order);
               startActivity(toDetail);
           }
       });
   }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initCheckBox();
        initRadioButton();
        initCountEditText();
        initSubmitBtn();

//        Order order = new Order();
//        order.addItem(new Item("雞腿",
//                10,80));
//        order.addItem(new Item("排骨",2,70));
//        order.addItem(new Item("燒肉",5,60));
//        order.readItems(it->{
//            Log.d("Howard","item:"+it);
//
//        });

    }
}