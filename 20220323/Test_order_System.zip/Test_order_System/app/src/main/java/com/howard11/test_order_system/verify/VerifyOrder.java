package com.howard11.test_order_system.verify;

import android.widget.CheckBox;

import java.util.List;

public class VerifyOrder {

    public static boolean verifyOrderCount(String count,
                                           CheckBox checkBox,

                                           List<VerifyMsg> verifyMsgs){
        int countInt = -1;
        String msg = checkBox.getText().toString()+":請入正確的數量";
        if (checkBox.isChecked()){
                try{
                    countInt =  Integer.parseInt(count);
                }catch (Exception ex){
                    if (verifyMsgs != null)
                       verifyMsgs.add(new VerifyMsg(msg));
                    return false;
                }

                if (countInt > 0){
                    return true;
                }else{
                    if (verifyMsgs != null)
                        verifyMsgs.add(new VerifyMsg(msg));
                    return false;
                }
            }
        return true;
    }

}
