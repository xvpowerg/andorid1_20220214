package com.howard11.mask_project.net;

import android.util.Log;

import androidx.annotation.NonNull;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class DownloadMaskJson {
    private String jsonUrl = "";
    private DownloadMaskJsonFinish finishCallback;
    public DownloadMaskJson(String jsonUrl){
            this.jsonUrl = jsonUrl;
    }
    public interface  DownloadMaskJsonFinish{
        void callBack(String json);
    }

    public void setFinishCallback(DownloadMaskJsonFinish finish){
        this.finishCallback = finish;
    }
    private class OkHttpCallBack implements Callback {

        @Override
        public void onFailure(@NonNull Call call, @NonNull IOException e) {
            Log.e("Howard","IOException:"+e);
        }

        @Override
        public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
            if (finishCallback != null){
                finishCallback.callBack(response.body().string());
            }
        }
    }

    public void start(){
        OkHttpClient.Builder okb = new OkHttpClient.Builder();
        OkHttpClient client =  okb.retryOnConnectionFailure(true).
                readTimeout(10, TimeUnit.SECONDS).build();
        Request.Builder rb = new Request.Builder();
        Request request = rb.url(jsonUrl).build();
        client.newCall(request).enqueue(new OkHttpCallBack());
    }
}
