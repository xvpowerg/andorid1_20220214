package com.howard11.mask_project.mask;

public class Properties {

    private String id;
    private  String name;
    private String phone;
    private String address;
    private int mask_adult;
    private int mask_child;

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public int getMask_adult() {
        return mask_adult;
    }

    public int getMask_child() {
        return mask_child;
    }

    @Override
    public String toString() {
        return "Properties{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", address='" + address + '\'' +
                ", mask_adult=" + mask_adult +
                ", mask_child=" + mask_child +
                '}';
    }
}
