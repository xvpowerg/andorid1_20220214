package com.howard11.mask_project.json;

import android.os.Handler;

import com.google.gson.Gson;
import com.howard11.mask_project.mask.MaskData;

import java.util.function.Consumer;

public class MaskJsonTools {
    public static void jsonToObject(String maskJson, Handler handler,
                                    Consumer<MaskData> consumer){
        Gson gson = new Gson();
        Thread thread = new Thread(()->{

            MaskData maskData = gson.fromJson(maskJson,
                    MaskData.class);

            handler.post(()->{
                consumer.accept(maskData);
            });


        });
        thread.start();
    }

}
