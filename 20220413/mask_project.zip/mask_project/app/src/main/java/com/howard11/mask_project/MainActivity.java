package com.howard11.mask_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;

import com.google.gson.Gson;
import com.howard11.mask_project.adpater.MaskDataAdapter;
import com.howard11.mask_project.json.MaskJsonTools;
import com.howard11.mask_project.mask.MaskData;
import com.howard11.mask_project.net.DownloadMaskJson;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    private ListView maskList = null;
    private MaskDataAdapter maskDataAdapter;
    private Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        maskList = findViewById(R.id.maskList);
        handler = new Handler();
    }

    @Override
    protected void onStart() {
        super.onStart();
        String jsonUrl = getString(R.string.mask_json_url);
        DownloadMaskJson dmj = new DownloadMaskJson(jsonUrl);
        dmj.start();
        dmj.setFinishCallback(json->{
            MaskJsonTools.jsonToObject(json,handler,maskData -> {
                Log.d("Howard","maskData:"+maskData.getFeatures().size());
                maskDataAdapter = new MaskDataAdapter(maskData);
                maskList.setAdapter(maskDataAdapter);
            });

        });
    }
}