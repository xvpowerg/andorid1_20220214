package com.howard11.mask_project.adpater;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.howard11.mask_project.R;
import com.howard11.mask_project.mask.Feature;
import com.howard11.mask_project.mask.MaskData;

import java.util.HashMap;
import java.util.List;

public class MaskDataAdapter extends BaseAdapter {
    private List<Feature> fList;
    public MaskDataAdapter(MaskData maskData){
            fList = maskData.getFeatures();
    }
    @Override
    public int getCount() {
        return fList.size();
    }

    @Override
    public Feature getItem(int position) {
        return fList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView nameTxt = null;
        TextView phoneTxt = null;
        TextView addressTxt = null;
        TextView adultTxt =  null;
        TextView  childTxt =  null;
        View view  =null;
        if (convertView != null){
            view = convertView;
         HashMap<String,TextView> map = (HashMap) convertView.getTag();
            nameTxt = map.get("nameTxt");
            phoneTxt = map.get("phoneTxt");
            addressTxt = map.get("addressTxt");
            adultTxt = map.get("adultTxt");
            childTxt = map.get("childTxt");
        }else{
             view  = LayoutInflater.from(parent.getContext()).inflate(R.layout.mask_adapter_layout,
                    parent,false);
             nameTxt = view.findViewById(R.id.nameTxt);
             phoneTxt = view.findViewById(R.id.phoneTxt);
             addressTxt = view.findViewById(R.id.addressTxt);
             adultTxt =  view.findViewById(R.id.adultTxt);
             childTxt =  view.findViewById(R.id.childTxt);
            HashMap<String,TextView> obj = new HashMap();
            obj.put("nameTxt",nameTxt);
            obj.put("phoneTxt",phoneTxt);
            obj.put("adultTxt",adultTxt);
            obj.put("childTxt",childTxt);
            obj.put("addressTxt",addressTxt);
            view.setTag(obj);
        }



        Feature feature =   getItem(position);
        nameTxt.setText(feature.getProperties().getName());
        phoneTxt.setText(feature.getProperties().getPhone());
        addressTxt.setText(feature.getProperties().getAddress());

        int adultCount = feature.getProperties().getMask_adult();
        int childCount =  feature.getProperties().getMask_child();
        if (adultCount < 100){
            adultTxt.setTextColor(Color.RED);
        }else{
            adultTxt.setTextColor(Color.BLACK);
        }
        if (childCount < 100){
            childTxt.setTextColor(Color.RED);
        }else{
            childTxt.setTextColor(Color.BLACK);
        }
        adultTxt.setText("成人:"+adultCount);
        childTxt.setText("兒童:"+childCount);
        return view;
    }
}
