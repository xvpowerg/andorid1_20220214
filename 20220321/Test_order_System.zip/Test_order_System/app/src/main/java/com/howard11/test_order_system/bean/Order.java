package com.howard11.test_order_system.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
public class Order {
    private ArrayList<Item> items = new ArrayList<>();
    private Category category;
    public enum Category{
        Internal,
        Takeout
    }
    public Category getCategory() {
        return category;
    }
    public void setCategory(Category category) {
        this.category = category;
    }

    public void addItem(Item item){
        items.add(item);
    }

    public void readItems(Consumer<Item> consumer){
        for (Item it : items){
            consumer.accept(it);
        }
    }

}
