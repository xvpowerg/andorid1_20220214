package com.howard11.test_fragment_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageFragment imageFragment;
       private void change(View view){
            int res = R.drawable.image1;
            switch (view.getId()){
                case R.id.img1Btn:
                    res = R.drawable.image1;
                    break;
                case R.id.img2Btn:
                    res = R.drawable.image2;
                    break;
                case R.id.img3Btn:
                    res = R.drawable.image3;
                    break;
                case R.id.img4Btn:
                    res = R.drawable.image4;
                    break;
            }
            int finalRes = res;
            imageFragment.changeImage((im)->{
                im.setImageResource(finalRes);
            });
       }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);

      ButtonFragment btnFragment = (ButtonFragment) getSupportFragmentManager().findFragmentById(R.id.btnFragment);
     imageFragment =
            (ImageFragment)getSupportFragmentManager().findFragmentById(R.id.imageFragment);

        btnFragment.initBtnOnClick(this::change);

        }

}