package com.howard11.test_fragment_1;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ButtonFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.d("Howard","ButtonFragment:"+container);
        return inflater.inflate(R.layout.buttons_layout,container,false);
    }


    public void initBtnOnClick(View.OnClickListener v){
        Button btn1 = getView().findViewById(R.id.img1Btn);
        Button btn2 = getView().findViewById(R.id.img2Btn);
        Button btn3 = getView().findViewById(R.id.img3Btn);
        Button btn4 = getView().findViewById(R.id.img4Btn);
        btn1.setOnClickListener(v);
        btn2.setOnClickListener(v);
        btn3.setOnClickListener(v);
        btn4.setOnClickListener(v);
    }
}


