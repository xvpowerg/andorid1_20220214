package com.howard11.test_notification2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private Random random = new Random();
    private int q = 0;
    private int max  = 100;
    private int min  = 1;
     private String chid = "guessID";

    private void createChannel(){
        NotificationManager nm =(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel =
                new NotificationChannel(chid,"guess", NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("des");
        nm.createNotificationChannel(channel);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button newBtn = findViewById(R.id.newBtn);
        Button submitBtn = findViewById(R.id.submitBtn);
        EditText  numberTxt =  findViewById(R.id.inputNumberTxt);
        submitBtn.setEnabled(false);

        newBtn.setOnClickListener(v->{
            q = random.nextInt(100)+1;
            v.setEnabled(false);
            submitBtn.setEnabled(true);
        });
//30
 //90
        submitBtn.setOnClickListener(v->{
            createChannel();
            int id = 1;
            NotificationCompat.Builder nb =
                    new NotificationCompat.Builder(this,chid);
            nb.setSmallIcon(R.drawable.msg);
            nb.setContentTitle("猜數字的結果");
            int number =
                    Integer.parseInt(numberTxt.getText().toString());
            String msg = null;
            if (number == q){
                Log.d("Howard","答對了");
                msg = "答對了";
                submitBtn.setEnabled(false);
                newBtn.setEnabled(true);
            }else if(number < q){
                    min = number;
            }else{
                max = number;
            }
            if (msg == null){
                msg = String.format("%d<?<%d",min,max);
            }
            nb.setContentText(msg);

            NotificationManagerCompat.from(this).notify(id,nb.build());
    //Log.d("Howard","min"+min+ "max:"+max);
           // newBtn.setEnabled(true);

        });
    }
}