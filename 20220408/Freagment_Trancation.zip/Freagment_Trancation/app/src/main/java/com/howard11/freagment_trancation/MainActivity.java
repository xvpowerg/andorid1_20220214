package com.howard11.freagment_trancation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private void onClick(View view){
        Fragment fragmentA = new FragmentA();
        Fragment fragmentB = new FragmentB();
        Fragment fragmentC = new FragmentC();

        FragmentTransaction ft =
                getSupportFragmentManager().beginTransaction();
        switch(view.getId()){
            case R.id.page1Btn:
                ft.replace(R.id.fragment_container,fragmentA).addToBackStack("FG");

                break;
            case  R.id.page2Btn:
                ft.replace(R.id.fragment_container,fragmentB).addToBackStack("FG");

              break;
            case R.id.page3Btn:
                ft.replace(R.id.fragment_container,fragmentC).addToBackStack("FG");
                break;
        }

        ft.commit();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button page1Btn = findViewById(R.id.page1Btn);
        Button page2Btn = findViewById(R.id.page2Btn);
        Button page3Btn = findViewById(R.id.page3Btn);


        page1Btn.setOnClickListener(this::onClick);
        page2Btn.setOnClickListener(this::onClick);
        page3Btn.setOnClickListener(this::onClick);

    }
}