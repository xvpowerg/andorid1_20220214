package com.howard11.ch1_test1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    private class ClickListener implements View.OnClickListener{
        private String msg;
        public ClickListener(){

        }
        public ClickListener(String msg){
            this.msg = msg;
        }
            public void  onClick(View view){
                Log.d("Howard","msg:"+msg);
            }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //findViewById一定要在setContentView之後呼叫
        Button btn = findViewById(R.id.msgBtn);

//        ClickListener listenr = new ClickListener("Hello!");
//        btn.setOnClickListener(listenr);

        //內部類!
//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(MainActivity.this,
//                        "Btn Click!!",Toast.LENGTH_LONG).show();
//            }
//        });
        btn.setOnClickListener(v->{
            Toast.makeText(this,"Test Click Lambda",Toast.LENGTH_SHORT).show();
        });

    }
}