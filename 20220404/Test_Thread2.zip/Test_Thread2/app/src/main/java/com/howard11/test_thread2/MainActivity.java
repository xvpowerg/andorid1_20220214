package com.howard11.test_thread2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private int[] images = {R.drawable.image1,R.drawable.image2,
                            R.drawable.image3,R.drawable.image4};
    private int count = 0;
    private boolean canRun = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button startBtn = findViewById(R.id.startBtn);
        Button stopBtn = findViewById(R.id.stopBtn);

        ImageView fruitImageView = findViewById(R.id.fruitImageView);
        stopBtn.setOnClickListener(v->{
            canRun = false;

        });
        startBtn.setOnClickListener(v->{
            canRun = true;
            Thread run =  new Thread(()->{
                while(canRun){
                    count = count % images.length;
                    runOnUiThread(()->{
                        fruitImageView.setImageResource(images[count++]);
                    });
                    try{
                        TimeUnit.SECONDS.sleep(1);
                    }catch (Exception e){

                    }
                }
            });
            run.start();

        });
    }
}