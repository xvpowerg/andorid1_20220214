package com.howard11.test_thread3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView imageView = findViewById(R.id.fruitImageView);
        Button startBtn=findViewById(R.id.startBtn);
        Button stopBtn = findViewById(R.id.stopBtn);
        stopBtn.setEnabled(false);
        MyImageLoop myImageLoop = new MyImageLoop(imageView);
        startBtn.setOnClickListener(v -> {

            myImageLoop.start(()->{
                startBtn.setEnabled(false);
                stopBtn.setEnabled(true);
            });

        });
        stopBtn.setOnClickListener(v->{
            myImageLoop.stop(()->{
                startBtn.setEnabled(true);
                stopBtn.setEnabled(false);

            });
        });
    }
}