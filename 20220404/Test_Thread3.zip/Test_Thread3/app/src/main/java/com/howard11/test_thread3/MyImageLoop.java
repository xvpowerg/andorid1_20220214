package com.howard11.test_thread3;

import android.widget.ImageView;

import java.util.concurrent.TimeUnit;
import android.os.Handler;
public class MyImageLoop {
    private int[] imageRes = {R.drawable.image1,R.drawable.image2,
                              R.drawable.image3,R.drawable.image4};
    private ImageView imageView;
    private  int count = 0;
    private boolean run = false;
    private Handler handler = new Handler();
    public MyImageLoop(ImageView imageView){
            this.imageView = imageView;
    }


    public void start(Runnable runnable){
        if (run) return;

        run = true;
            Thread thread = new Thread(()->{
                  while(run){
                      count %= imageRes.length;
                      handler.post(()->{imageView.setImageResource(imageRes[count++]);});

                      try{
                          TimeUnit.SECONDS.sleep(1);
                      }catch (Exception ex){

                      }

                  }
            });


        thread.start();
        if(runnable!= null)
        runnable.run();
    }


    public void stop(Runnable runnable){
        run = false;
        if(runnable!= null)
        runnable.run();
    }




}
