package com.howard11.test_thread;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class MainActivity extends AppCompatActivity {
private Handler handler = new Handler();
private TextView timeView ;
private void testTime(){
    LocalTime now = LocalTime.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
    String time = now.format(formatter);
    //String time = String.format(now.getHour()+":"+now.getMinute()+":"+now.getSecond());
    timeView.setText(time);
    Log.d("Howard","Name:"+Thread.currentThread().getName());
    handler.postDelayed(this::testTime,1000);

}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button startBtn = findViewById(R.id.startBtn);
         timeView = findViewById(R.id.timeView);
        startBtn.setOnClickListener(v->{
             handler.postDelayed(this::testTime,1000);

        });
    }
}