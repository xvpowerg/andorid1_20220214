package com.howard11.test_spinner2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String[] status = new String[]{"未婚","已婚"};
        StringBuffer sb = new StringBuffer();
        Spinner statusSpinner =  findViewById(R.id.status_spinner);
        Button submitBtn = findViewById(R.id.submitBtn);
        submitBtn.setOnClickListener(v->{
            Log.d("Howard","status:"+sb);

        });
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,new String[]{"未婚","已婚"});
        statusSpinner.setAdapter(arrayAdapter);
        statusSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.d("Howard","onItemSelected:"+position);
                sb.setLength(0);
                sb.append(status[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}