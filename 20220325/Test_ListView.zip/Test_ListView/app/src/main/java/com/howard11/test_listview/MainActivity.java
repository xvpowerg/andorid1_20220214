package com.howard11.test_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView = findViewById(R.id.myListView);
        ArrayList<String> list = new ArrayList();
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        list.add("E");
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        list.add("E");
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        list.add("E");
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        list.add("E");
        ArrayAdapter<String> data = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1, list);
        listView.setAdapter(data);

        listView.setOnItemClickListener((p,v,pos,id)->{
            Log.d("Howard","p:"+p+" v:"+v+" pos:"+pos+" id:"+id);

        });
    }
}