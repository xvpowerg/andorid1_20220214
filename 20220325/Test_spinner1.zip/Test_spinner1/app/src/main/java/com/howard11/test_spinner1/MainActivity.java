package com.howard11.test_spinner1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner citySpinner =  findViewById(R.id.city_spinner);
        Spinner sexSpinner = findViewById(R.id.sex_spinner);
        ArrayAdapter<String> spinnerValues = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,new String[]{"高雄","台中","台北"});
        citySpinner.setAdapter(spinnerValues);

        ArrayAdapter<String> sexSpinnerAdapter= new ArrayAdapter<>(this,
                R.layout.my_spinner_layout,R.id.sex,
                new String[]{"男","女"});
        sexSpinner.setAdapter(sexSpinnerAdapter);


    }
}