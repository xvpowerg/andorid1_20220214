package com.howard11.test_spinner4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Optional;

public class MainActivity extends AppCompatActivity {
    private ArrayList<String[]> countryNameList = new ArrayList<>();
    private Spinner countrySpinner;
    private void initCountryList(){
        countryNameList.add(getResources().getStringArray(R.array.country_0));
        countryNameList.add(getResources().getStringArray(R.array.country_1));
        countryNameList.add(getResources().getStringArray(R.array.country_2));
    }

    private void setCountryAdapter(int position){
         String[] countries=  countryNameList.get(position);
        ArrayAdapter<String> spinnerArrayAdapter = (ArrayAdapter)countrySpinner.getAdapter();
        Optional<ArrayAdapter>  arrayAdapterOp =  Optional.ofNullable(spinnerArrayAdapter);
        spinnerArrayAdapter = arrayAdapterOp.orElseGet(()->{
            ArrayAdapter<String> arrayAdapter =  new ArrayAdapter<>(this,
                            android.R.layout.simple_list_item_1,
                            android.R.id.text1);
                      countrySpinner.setAdapter(arrayAdapter);
                    return arrayAdapter;
                }

        );
        spinnerArrayAdapter.clear();
        spinnerArrayAdapter.addAll(countries);



    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String[] cityArray = getResources().getStringArray(R.array.cities);
        Spinner citySpinner =  findViewById(R.id.city_spinner);
         countrySpinner =   findViewById(R.id.country_spinner);
        TextView cityName = findViewById(R.id.city_name);
        initCountryList();
        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,cityArray);
        citySpinner.setAdapter(cityAdapter);
        citySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cityName.setText(cityArray[position]);
                setCountryAdapter(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}