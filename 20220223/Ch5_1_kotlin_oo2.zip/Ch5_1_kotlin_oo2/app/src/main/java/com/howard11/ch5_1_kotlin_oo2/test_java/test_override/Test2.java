package com.howard11.ch5_1_kotlin_oo2.test_java.test_override;

public class Test2 {
}
