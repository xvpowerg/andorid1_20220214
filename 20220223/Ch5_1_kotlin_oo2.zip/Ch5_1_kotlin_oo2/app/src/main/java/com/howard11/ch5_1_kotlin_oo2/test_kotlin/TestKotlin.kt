package com.howard11.ch5_1_kotlin_oo2.test_kotlin

class TestKotlin {

    var x:Int
    constructor(){
            x = 10
    }
}