package com.howard11.ch5_1_kotlin_oo2.test_java;

public class Person {
    private String name;
//    public Person(){
//
//    }
    public Person(String name){
        this.name = name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return this.name;
    }

}
