package com.howard11.ch5_1_kotlin_oo2.test_java;

public class Teacher extends Person{
    private int age;
    public Teacher(String name){
        super(name);
    }
    public void setAge(int age){
        this.age = age;
    }
   public int getAge(){
        return age;
   }

   public String getName(){
        return "T:"+super.getName();
   }
}
