package com.howard11.ch5_1_kotlin_oo2.test_java.test_override;

import android.util.Log;

public class Test1 {

    //讀取權限只能開放
    //public 跨package可讀取
    //protected 跨package繼承後可讀取
    //default(空白) 相通package可讀取
    //private 在相同類別內可讀取
    //回傳值如果是基本型態必須一樣 如果是參考可以是子類
    //方法名稱與參數要一樣
    //例外可拋或不拋 或拋出子類
    public void testPublic(){
        //Log.d("")
    }
}
