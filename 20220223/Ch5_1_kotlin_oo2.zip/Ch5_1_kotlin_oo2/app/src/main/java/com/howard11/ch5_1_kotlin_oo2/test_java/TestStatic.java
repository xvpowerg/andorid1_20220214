package com.howard11.ch5_1_kotlin_oo2.test_java;

import android.util.Log;

public class TestStatic {
    String value1;
    static String value2;

    public void testValueMethod(String v1,String v2){
            value1 = v1;
            value2 = v2;
    }

    public void print(){
        Log.d("Howard","v1:"+
                value1+" v2:"+value2);
    }

    public static void testStatic(){
        //靜態只能呼叫靜態
        //value1 = 10;
    }

}
