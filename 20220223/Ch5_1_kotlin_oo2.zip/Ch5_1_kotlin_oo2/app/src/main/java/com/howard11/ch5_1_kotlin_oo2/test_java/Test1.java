package com.howard11.ch5_1_kotlin_oo2.test_java;

import android.util.Log;

public class Test1 {
    public static void testMethod(){
        /*byte 8bit -127~128
        short 16bit
        int 32bit 預設為int
        long 64bit
        大不可到小
        小可到大
        */
//        byte v1 = 12;
//        int v2 = v1;
//
//        long v3 = 2147483648L;
//        float f1 = 25.6f;//32bit
//        double d1 = 25.6;//64bit
//        byte b2;
        Student st1= new Student("Ken");
        st1.setAge(-10);
        Log.d("Howard","age:"+st1.getAge()+"name:"+st1.getName());
    }

    public static void testMethod2(){
        Student st2 = new Student("Lindy");
        st2.setAge(20);
        Log.d("Howard","age:"+st2.getAge()+
                "name:"+st2.getName());
        Teacher te1 = new Teacher("LuLu");
        te1.setAge(25);
        Log.d("Howard","age:"+te1.getAge()+
                "name:"+te1.getName());


    }
}
