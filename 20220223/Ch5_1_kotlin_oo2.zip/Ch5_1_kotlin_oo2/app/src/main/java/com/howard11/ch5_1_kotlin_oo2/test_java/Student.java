package com.howard11.ch5_1_kotlin_oo2.test_java;

public class Student extends  Person{
    private int age;
    public Student(String name){
        super(name);
    }
    public void setAge(int age){
        if (age < 0 || age > 200){
            //拋出例外
            //參數錯誤的例外
           throw
        new IllegalArgumentException("錯誤年齡");
        }
        this.age = age;
    }

    public int getAge(){
        return this.age;
    }
    @Override
    public String getName(){
        //super. 呼叫父類別的方法
        String name = "S:"+super.getName();
        return name;
    }

}
