package com.howard11.ch5_1_kotlin_oo2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.howard11.ch5_1_kotlin_oo2.test_java.Test1
import com.howard11.ch5_1_kotlin_oo2.test_java.TestStatic

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //測試例外
        //Test1.testMethod()

        //測試靜態
//        val ts1 = TestStatic()
//        val ts2 = TestStatic()
//        ts1.testValueMethod("TS1 Static1 V1",
//            "TS1 V2")
//        ts2.testValueMethod("TS2 Static1 V1",
//            "TS2 V2")
//
//        ts1.print()
//        ts2.print()

        Test1.testMethod2()
    }
}