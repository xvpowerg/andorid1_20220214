package com.howard11.ch5_2_kotlinoo3_java.test_exception;

import android.util.Log;
import java.io.IOException;
public class TestException {
        //UnCatch 只要繼承RuntimeException都是unCatch例外
    public void testUnCatch(int v){
        if (v > 100){
            //拋出例外後 函數會中斷
            throw new IllegalArgumentException();
        }
        Log.d("Howard","V:"+v);
    }
    public void testCatched(int v2)throws  IOException{
        if (v2 >200){
            //觸發
            throw new IOException();
        }
        Log.d("Howard","V2:"+v2);
    }

}
