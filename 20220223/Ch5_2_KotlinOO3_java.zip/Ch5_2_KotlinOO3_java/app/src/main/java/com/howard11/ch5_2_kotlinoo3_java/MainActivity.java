package com.howard11.ch5_2_kotlinoo3_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.howard11.ch5_2_kotlinoo3_java.test_exception.TestException;
import com.howard11.ch5_2_kotlinoo3_java.test_override.Test1;
import com.howard11.ch5_2_kotlinoo3_java.test_override.Test2;
import com.howard11.ch5_2_kotlinoo3_java.test_override.p2.Test3;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        Test1 t1 = new Test2();
//        t1.testPublic();
//        t1.testOtherMethod();
//        Test3 t3 = new Test3();
//        t3.testPublic();
        TestException te = new TestException();
       // te.testUnCatch(1000);
        try{
            te.testCatched(5000);
        }catch (IOException ex){
            Log.d("Howard","IOEx:"+ex);
        }

    }
}