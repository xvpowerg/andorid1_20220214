package com.howard11.ch5_2_kotlinoo3_java.test_override;

import android.util.Log;

public class Test2 extends Test1{

    public void testPublic(){
        Log.d("Howard","Test2 testPublic!!");
    }

    @Override
    protected void testProtected() {
        Log.d("Howard","Test2 protected!!");
    }

    @Override
    void testDefault() {
        Log.d("Howard","Test2 Default!!");
    }
    //不是複寫
    public void testPrivate(){
        Log.d("Howard","Test2 testPrivate!!");
    }
}
