package com.howard11.ch5_2_kotlinoo3_java.test_override.p2;
import android.util.Log;

import com.howard11.ch5_2_kotlinoo3_java.test_override.Test1;
public class Test3 extends Test1{
    @Override
    public void testPublic() {
        this.testProtected();
        Log.d("Howard","Test3 testPublic!!");
    }
}
