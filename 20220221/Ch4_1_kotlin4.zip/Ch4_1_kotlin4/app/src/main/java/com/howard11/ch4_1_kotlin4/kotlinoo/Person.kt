package com.howard11.ch4_1_kotlin4.kotlinoo

class Person {
    var name:String = ""
    var age:Int = 0
    constructor(){this.age = 10}
    constructor(name:String,age:Int){
        this.name = name
        this.age = age
    }


}