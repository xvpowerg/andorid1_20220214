package com.howard11.ch4_1_kotlin4.javaoo;

import android.util.Log;

public class TestJavaOO {

    public static  void run(){
        Student st = new Student();
        st.setAge(10);
        st.setName("Ken");
        Log.d("Howard",
                "name:"+st.getName()+" age:"+st.getAge());
        Student st2 = new Student("Vivin",25);
        Log.d("Howard",
                "name:"+st2.getName()+" age:"+st2.getAge());
    }
}
