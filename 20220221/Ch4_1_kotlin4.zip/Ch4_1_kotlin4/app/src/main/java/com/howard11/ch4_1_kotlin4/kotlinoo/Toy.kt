package com.howard11.ch4_1_kotlin4.kotlinoo

class Toy {
    var price:Int=0
    get(){
        return field
    }
    set(value) {
        field = value
    }
    var name:String=""
    get() {
        return field
    }
    set(value) {
        field = value
    }
    constructor(){
    }
    constructor(name:String,price:Int){
        this.name = name
        this.price = price
    }
}