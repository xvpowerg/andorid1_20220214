package com.howard11.ch4_1_kotlin4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.howard11.ch4_1_kotlin4.javaoo.TestJavaOO

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val t1 = TestMethod()
        //circle
        //半徑r 預設 1
        //功能a 1.求面積 PI * R^2  2.求周長 2 * PI * R 預設為2
        //訊息 m 預設為空白
        t1.circle()
        t1.circle(m="圓面積",a=1,r=10)
        Log.d("Howard","sum:${t1.sum(1,4,5)}")
        val s1 =  t1.joinNames(names= arrayOf("Ken","Vivin","Lindy"))
       val s2 =  t1.joinNames("產品清單:",".",
           "iPhone","ipad","Ps5",len=2)
        Log.d("Howard","s1:$s1 s2:$s2")
        Log.d("Howard","max : ${t1.cmp(2,8,1,9,6, cmpType = 2)}")


        val tkoo1 = TestKotlinOO1()
        tkoo1.testPerson()
        tkoo1.testAnimal()

        TestJavaOO.run()

    }
}