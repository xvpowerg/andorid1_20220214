package com.howard11.ch4_1_kotlin4

import android.util.Log

class TestMethod {
    //circle
    //半徑r 預設 1
    //功能a 1.求面積 PI * R^2  2.求周長 2 * PI * R 預設為2
    //訊息 m 預設為空白

    fun  circle(r:Int = 1,a:Int = 2,m:String=""){
            val PI = 3.1415f
            var ans  = 0.0f
            when(a){
                1->ans = PI * r * r
                2 ->ans = 2 * PI * r
            }
        Log.d("Howard","$m$ans")
    }

    fun sum(vararg values:Int):Int{
            var result = 0
        for (v in values){
              result += v
        }
        return result
    }

    fun joinNames(title:String="",end:String = "x",
                  vararg names:String,len:Int=names.size):String{
            var namesString = title
            var count = 0
         for (name in names){
             if(count == len) break
             namesString += name+" "
             count++
         }
        return namesString + end
    }

    /*
        //設計一個方法cmp
      // 1 可傳N筆整數 values
    //  2 可傳入類型 cmpType 1 最大值(預設) 2 最小值
    //3 回傳找到的數值
     */
    fun cmp(vararg values: Int,cmpType:Int=1):Int{
        var tmp = 0
         if (values.isNotEmpty())  tmp =values[0]
        for (v in values){
                when(cmpType){
                    1 -> if(v > tmp) tmp = v
                    2 -> if(v < tmp) tmp = v
                }
        }
        return tmp
    }
}