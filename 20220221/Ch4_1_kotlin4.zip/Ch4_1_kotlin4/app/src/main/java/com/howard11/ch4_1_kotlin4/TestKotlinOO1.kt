package com.howard11.ch4_1_kotlin4

import android.util.Log
import com.howard11.ch4_1_kotlin4.kotlinoo.Animal
import com.howard11.ch4_1_kotlin4.kotlinoo.Person

class TestKotlinOO1 {

    fun testPerson(){
        val p = Person()
        Log.d("Howard","p1:{${p.age} ${p.name}}")
        val p2 = Person(age=18,name="Ken")
        Log.d("Howard","p1:${p2.name} ${p2.age}")
    }
    fun testAnimal(){
            val animal = Animal()
        animal.setAge(30)
        animal.name = "Ken"
        Log.d("Howard","name:${animal.name} age:${animal.getAge()}")
    }
}