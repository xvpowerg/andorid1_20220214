package com.howard11.ch4_1_kotlin4.kotlinoo

import android.util.Log
class Animal {
    constructor(){
        toy = Toy()
    }
    constructor(name:String,age:Int){
            toy = Toy()
    }
    //lateinit 之後我會初始化 現在不要出現錯誤
    lateinit var toy:Toy
    var name:String = ""
        //動物希望有一個玩具(Toy)
        //Toy
        //屬性 有price 屬性
        //name
        //希望有建構式可設定 Toy的name
     get(){
         Log.d("Howard","get Name")
        return field
    }
    set(value){
        if (value.isNotEmpty()){
            field = value
        }
        Log.d("Howard","set Name")
    }
    private var age:Int = 0
    fun getAge():Int{
        Log.d("Howard","getAge")
        return age
    }
    fun setAge(age:Int){
        //如果age 小於0 大於300
        //在Log顯示錯誤年齡
        //數值不會設定
        if (age < 0 || age > 300){
            Log.d("Howard","錯誤年齡")
        }else{
            this.age = age
        }
        Log.d("Howard","setAge")

    }
}