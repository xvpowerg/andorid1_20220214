package com.howard11.ch2_1_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //test1()
       // test2()
        //test3()
       // test4(3)
       // test5(2.5f)
        //Log.d("Howard",test6(32))
      // Log.d("Howard","msg:${test7(1)}")
        //test8()
        //test9()
        test10()
    }

    fun test10(){
        var count = 1
        var end = 10
        while(count < end){
            Log.d("Howard","count:$count")
            count+=2
        }
    }
    fun test9(){
        //step 2 加2的意思
//        for (n in 0..20 step 2){
//            Log.d("Howard","n:$n")
//        }

        for (n in 20 downTo 1 step 2){
                Log.d("Howard","downTo:$n")
        }


    }

    fun test8(){
        val n = 7
        val rangex = 1 ..n
        Log.d("Howard","rangex:${rangex.javaClass.kotlin.simpleName}")
        for (i in 1 ..n){
                Log.d("Howard","i:$i")
        }

        val range2 = 1..5
        for (x in range2){
            Log.d("Howard","x:$x")
        }
    }

    fun test7(month:Int):String{
       val msg =  when(month){
            in 3..5 ->"春"
            in 6..8->"夏"
            in 9..11->"秋"
            12,1,2->"冬"
            else->"住火星"
        }
        //3 4 5 春
        //6 7 8 夏
        //9 10 11 秋
        // 12 1 2 冬
        //住在火星
        return msg
    }

    fun test6(age:Int):String{
//        val msg = when{
//            age >= 0 && age < 18->"未成年"
//            age >=18 && age < 65 ->"成年"
//            age >= 65 && age < 300 ->"老年"
//            else ->"仙人"
//        }
        val msg = when(age){
            in 0..17->"未成年"
            in 18..64->"成年"
            in 65..300 ->"老年"
            else ->"仙人"
        }
        return msg
    }
    //Any 不限制類型
    fun test5(any:Any){
        when(any){
            is String ->{Log.d("Howard","String")}
            is Int ->Log.d("Howard","Int")
            is Float ->Log.d("Howard","Float")
            else ->Log.d("Howard","Error")
        }
    }
    fun test4(action: Int){
        when(action){
            1->{Log.d("Howard","Jump")}
            2->{Log.d("Howard","Fly")}
            else ->{Log.d("Howard","Error!!")}
        }
    }
    fun test1(){
        //標準型 非常數
        var height : Float = 175.2f
        var age :Int = 28
        Log.d("Howard","Height:"+height+"age:"+age)
        age = 32
        Log.d("Howard","age:"+age)
        val value1:String = "Test1"
       // value1 = "Ken"
        Log.d("Howard","value1:"+value1)
    }
    fun  test2(){
          val age:Int = 10
        val name:String = "Ken"
        val msg = "Name:$name Age:$age"
        Log.d("Howard",msg)
        val v1 = 20
        val v2 = 10
        val msg2 = "ans:$v1/$v2"
        Log.d("Howard","msg2:$msg2")
        val msg3 = "$v1/$v2=${v1 / v2}"
        Log.d("Howard","msg3:$msg3")
        //""" 在範圍內的都是字串
        val path = """C:\MyFile\drums"""
        Log.d("Howard","Path:$path")
        val context ="""<H1>標題1</H1>
                <p>ghijk</p>
                <p>lmnopq</p>"""
       Log.d("Howard","msg:$context")

        //自動推斷類型
        val n1 = "123".toInt()
        val v3:Float = 1.5f
        Log.d("Howard","n1:$n1 v3: $v3")
    }


    fun test3(){
        val score = 25
        val msg = if (score >= 60){
            Log.d("Howard","pass")
            "PASS"
        }else{
            Log.d("Howard","FAIL")
            "FAIL"
        }
        Log.d("Howard","msg:$msg")
    }




}