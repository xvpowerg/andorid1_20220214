package com.howard11.ch2_1_kotlin;

public class TestJava {
    public static  void testCode(){
        float f = Float.parseFloat("15.2");
         int age = 10;
        age = 25;

        String s1 = "Ken";
        int height= 180;
        System.out.println(String.format("name:%s height:%d",s1,height));

        for(int i = 1;i<10;i++){
            System.out.println(i);
        }
    }


}
