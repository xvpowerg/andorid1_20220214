package com.howard11.ch3_2_kotlin2;

import android.util.Log;

public class TestJava {

    public static void foreachStringArray(String[] data){
            for (String v : data){
                Log.d("Howard","String:"+v);
            }
    }

    public static void foreachIntArray(int[] intArray){
            for(int v : intArray){
                Log.d("Howard","v:"+v);
            }
    }
    public static void foreachIntegerArray(Integer[] intArray){
            for (Integer v : intArray){
                Log.d("Howard","v:"+v);
            }
    }

    public static void foreachFloatArray(float[] floatArray){
            for (float f : floatArray){
                Log.d("Howard","f:"+f);
            }
    }
}
