package com.howard11.ch3_2_kotlin2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //test1()
        //test2()
        //test3()
        //testArray4()
        //testArray5()
        //testArray6()
        testArray7()
    }

        fun testArray7(){
                val strArray = arrayOf<String>("Ken","Vivin","Lindy")
                TestJava.foreachStringArray(strArray)
                val intArray = arrayOf<Int>(20,50,60)
            //TestJava.foreachIntArray 因為參數是基本型態 所以無法相容 Integer
            //TestJava.foreachIntArray(intArray);
            TestJava.foreachIntegerArray(intArray)
            val intArray2 = IntArray(5){it+1}
            Log.d("Howard","intArray2:${intArray2.javaClass.kotlin.simpleName}")
            TestJava.foreachIntArray(intArray2)
            val intArray3 = intArrayOf(5,9,8,11,1)
            intArray3.sort()
            TestJava.foreachIntArray(intArray3)
            val floatArray1 = floatArrayOf(1.5f,8.2f,3.9f,5.1f)
            TestJava.foreachFloatArray(floatArray1)
            //在TestJava foreachFloatArray(float[] floatArray)
            // 希望輸出 1.5 8.2 3.9 5.1

        }

    fun testArray6(){
        //kotlin 的Array
        val defArray = arrayOf(10,20,30)
        Log.d("Howard",defArray.toString())
        Log.d("Howard",
            "simpleName:${defArray.javaClass.kotlin.simpleName}")
        val defArray2 = Array<String>(5){""}
        Log.d("Howard","defArray2:${defArray2.toString()}")
        Log.d("Howard","simpleName:${defArray2.javaClass.kotlin.simpleName}")


    }
    fun testArray5(){
        val defArray = Array<Int>(10){
            Random.nextInt(1,100)
        }
        val value1 = defArray.joinToString()
        Log.d("Howard","value1:$value1")
        defArray.sort()
        val value2 = defArray.joinToString()
        Log.d("Howard","value2:$value2")
        //大到小
        val defArray2 = Array<Int>(10){ Random.nextInt(1,1000)}
        val value3  = defArray2.joinToString()
        Log.d("Howard","value3:$value3")
        //sortedArray系列都不會影響原本的Array 回傳新的陣列
        val newDescArray = defArray2.sortedArrayDescending()
        //sortDescending 會改變原本的陣列
        //defArray2.sortDescending()
        val value4  = defArray2.joinToString()
        Log.d("Howard","value4:$value4")
        val value5 = newDescArray.joinToString(separator = "#")
        Log.d("Howard","value5:$value5")

    }

    fun testArray4(){
            val defArray = Array<String>(5){i-> "value:$i"}
        defArray.forEach { Log.d("Howard",it) }
        //希望偶數的index數值為1 奇數的index數值為0
        val intArray = Array<Int>(5){i->if (i%2 == 0) 1 else 0}
        intArray.forEach { Log.d("Howard","$it") }

    }

    fun test3(){
        val names = arrayOf("Ken","Vivin","Lindy")
        Log.d("Howard","name:${names[0]}")
        names[0] = "Iris"
        Log.d("Howard","name:${names[0]}")

        for (i in 0 until  names.size){
            Log.d("Howard","$i:${names[i]}")
        }

        for (v in names){
            Log.d("Howard","value:$v")
        }

        names.forEach {
            Log.d("Howard","value:$it")
        }
        names.forEachIndexed {
                index, s ->Log.d("Howard","$index : $s")
        }

    }

    fun test2(){
      bye@  for (i in 1..5){
            Log.d("Howard","Start===========================")
            for (k in 1 .. 3){
                if (i == 2) break@bye
                Log.d("Howard","$i:$k")
            }
            Log.d("Howard","End===========================")
        }
    }

    fun test1(){
            for (i in 1 ..10){
                //if ( i == 6) break
                if ( i == 6) continue
                Log.d("Howard","i:$i")
            }
    }

}