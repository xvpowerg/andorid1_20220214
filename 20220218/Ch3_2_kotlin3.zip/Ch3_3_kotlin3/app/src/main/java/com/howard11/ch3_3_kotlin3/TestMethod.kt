package com.howard11.ch3_3_kotlin3

import android.util.Log

class TestMethod {
        fun test1Method(){
            Log.d("Howard","TestMethod test1")
        }

    fun test2Method(a:Int,b:Int):Int{
        val ans = a *a + b * b
        return ans
    }


    fun test2Method(a:Float,b:Float):Float{
        val ans = a * a + b * b
        return ans
    }

     fun initBox(height:Int = 1,width:Int = 2,id:String= "empty"){
         val area = height * width
         Log.d("Howard",
             "area:$area height:$height width:$width id:$id")
     }


}