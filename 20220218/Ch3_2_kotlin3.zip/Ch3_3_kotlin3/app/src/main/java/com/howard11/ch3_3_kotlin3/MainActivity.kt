package com.howard11.ch3_3_kotlin3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val test1 = TestMethod()
        test1.test1Method()
        Log.d("Howard","ans:${test1.test2Method(10,20)}")
        Log.d("Howard","ans:${test1.test2Method(5.2f,3.1f)}")
        test1.initBox(2,5,"123")
        test1.initBox()
        test1.initBox(3)
        test1.initBox(8,6)
        test1.initBox(id="456", width = 12)
        //circle
        //半徑r 預設 1
        //功能a 1.求面積 PI * R^2  2.求周長 2 * PI * R 預設為2
        //訊息 m 預設為空白
    }
}