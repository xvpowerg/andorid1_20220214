package com.howard11.test_notification2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private Random random = new Random();
    private int q = 0;
    private int max  = 100;
    private int min  = 1;
     private String chid = "guessID";

    private void createChannel(){
        NotificationManager nm =(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel =
                new NotificationChannel(chid,"guess", NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("des");
        nm.createNotificationChannel(channel);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button newBtn = findViewById(R.id.newBtn);
        Button submitBtn = findViewById(R.id.submitBtn);
        EditText  numberTxt =  findViewById(R.id.inputNumberTxt);
        submitBtn.setEnabled(false);

        newBtn.setOnClickListener(v->{
            q = random.nextInt(100)+1;
            v.setEnabled(false);
            submitBtn.setEnabled(true);
        });
//30
 //90
        submitBtn.setOnClickListener(v->{
            createChannel();
            int number =
                    Integer.parseInt(numberTxt.getText().toString());
            if (number == q){
                Log.d("Howard","答對了");
                submitBtn.setEnabled(false);
                newBtn.setEnabled(true);
            }else if(number < q){
                    min = number;
            }else{
                max = number;
            }
    Log.d("Howard","min"+min+ "max:"+max);
           // newBtn.setEnabled(true);

        });
    }
}