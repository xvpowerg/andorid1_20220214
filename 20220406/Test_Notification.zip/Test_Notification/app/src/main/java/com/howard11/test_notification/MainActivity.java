package com.howard11.test_notification;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private String CHANNEL_ID = "msgID";
        private void createNotificationChannel(){
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O)
                return ;
            NotificationManager nm =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel tmpCh = nm.getNotificationChannel(CHANNEL_ID) ;
            if (tmpCh != null){
                return;
            }
            String name = "TestNotification";
            String desName = "desName";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID,
                    name,importance);
            notificationChannel.setDescription(desName);
            nm.createNotificationChannel(notificationChannel);
        }
        private void testN1(View view){
            createNotificationChannel();
            int id = 1;
            NotificationCompat.Builder nb
                    = new NotificationCompat.Builder(this,CHANNEL_ID);
            nb.setSmallIcon(R.drawable.msg);
            nb.setContentTitle("Title");
            nb.setContentText("針對混合辦公型態，Windows 11協助企業加強管理員工使用設備，" +
                    "包含避免網路釣魚風險、個人資料加密、採零信任安全防護設計、即時阻止使用可能帶有惡意攻擊的應" +
                    "用程式，並且在操作系統過程隨時確保密碼強度安全，或是透過即時遠距線上協助方式，讓企業內" +
                    "部IT人員可以透過線上方式解決遠距工作員工所面臨設備使用問題，過程中也會確保所有資訊及隱私安全。\n" +
                    "微軟在去年推出的Windows 11作業系統加入諸多對應混合工作模式功能，並且宣布推" +
                    "出可對應各類連網裝置使用的Windows 365雲端PC服務之後，此次更進一步針對更多後疫情" +
                    "時代使用需求做了諸多升級。");
            nb.setPriority(NotificationCompat.PRIORITY_DEFAULT);

            NotificationManagerCompat.from(this).notify(id,nb.build());
        }
    private void testN2(View view){
            int id = 2;
        createNotificationChannel();
        NotificationCompat.Builder nb  =
                new NotificationCompat.Builder(this,CHANNEL_ID);
        NotificationCompat.BigTextStyle biStyle = new NotificationCompat.BigTextStyle();
        biStyle =  biStyle.bigText("針對混合辦公型態，Windows 11協助企業加強管理員工使用設備，" +
                "包含避免網路釣魚風險、個人資料加密、採零信任安全防護設計、即時阻止使用可能帶有惡意攻擊的應" +
                "用程式，並且在操作系統過程隨時確保密碼強度安全，或是透過即時遠距線上協助方式，讓企業內" +
                "部IT人員可以透過線上方式解決遠距工作員工所面臨設備使用問題，過程中也會確保所有資訊及隱私安全。\n" +
                "微軟在去年推出的Windows 11作業系統加入諸多對應混合工作模式功能，並且宣布推" +
                "出可對應各類連網裝置使用的Windows 365雲端PC服務之後，此次更進一步針對更多後疫情" +
                "時代使用需求做了諸多升級。");
        nb.setSmallIcon(R.drawable.msg2);
        nb.setStyle(biStyle);
        nb.setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManagerCompat.from(this).notify(id,nb.build());
    }
    private void testN3(View view){
            int requestCode = 100;
            int id = 3;
        Intent openActivityIntent =
                new Intent(this,TestNotificationActivity.class);
        openActivityIntent.putExtra("msg","針對混合辦公型態，Windows 11協助企業加強管理員工使用設備，" +
                "包含避免網路釣魚風險、個人資料加密、採零信任安全防護設計、即時阻止使用可能帶有惡意攻擊的應" +
                "用程式，並且在操作系統過程隨時確保密碼強度安全，或是透過即時遠距線上協助方式，讓企業內" +
                "部IT人員可以透過線上方式解決遠距工作員工所面臨設備使用問題，過程中也會確保所有資訊及隱私安全。\n" +
                "微軟在去年推出的Windows 11作業系統加入諸多對應混合工作模式功能，並且宣布推" +
                "出可對應各類連網裝置使用的Windows 365雲端PC服務之後，此次更進一步針對更多後疫情" +
                "時代使用需求做了諸多升級。");
        openActivityIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,
                requestCode,openActivityIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n =  new NotificationCompat.Builder(this,CHANNEL_ID).
                setSmallIcon(R.drawable.msg4).
                setContentTitle("Title").
                setContentText("你有新訊息").
                setPriority(NotificationCompat.PRIORITY_MAX).
                setContentIntent(pendingIntent).
                setAutoCancel(true).build();
           NotificationManagerCompat.from(this).notify(id,n);
    }
    private int count = 0;
    private void testN4(View view){
            int max = 100;
            int id = 4;
            count +=10;
            NotificationCompat.Builder builder =
                    new NotificationCompat.Builder(this,CHANNEL_ID);
            builder.setContentTitle("Download....");
            builder.setContentText("Download in Progress:"+count);
            builder.setSmallIcon(R.drawable.msg5);
            builder.setPriority(NotificationCompat.PRIORITY_LOW);
            Runnable run = ()->{
                    for (int i = 10;i <= max;i+=10){
                        builder.setProgress(max,i,false);
                        NotificationManagerCompat.from(this).notify(id,builder.build());
                        try{
                            Thread.sleep(1000);
                        }catch (Exception ex){
                            
                        }

                    }
                builder.setContentText("完成");
                builder.setProgress(0,0,false);
                NotificationManagerCompat.from(this).notify(id,builder.build());
            };

            Thread t1 = new Thread(run);
            t1.start();
//            NotificationManagerCompat.from(this).notify(id,builder.build());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        Button btn4 = findViewById(R.id.btn4);

        btn1.setOnClickListener(this::testN1);
        btn2.setOnClickListener(this::testN2);
        btn3.setOnClickListener(this::testN3);
        btn4.setOnClickListener(this::testN4);
    }
}