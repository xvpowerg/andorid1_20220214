package com.howard11.test_notification;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class TestNotificationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification_layout);
        Intent data = getIntent();
        TextView msgTxt = findViewById(R.id.msgTxt);
        String msg = data.getStringExtra("msg");
        msgTxt.setText(msg);
    }
}
