package com.howard11.test_switch_btn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Switch sw1 =  findViewById(R.id.imageSwitch);
       ToggleButton toggleButton =
               findViewById(R.id.toggleButton);
        ImageView im2 = findViewById(R.id.imageView2);
       // im2.setVisibility(View.GONE);
       ImageView im1 = findViewById(R.id.imageView1);
        //im1.setVisibility(View.INVISIBLE);
        sw1.setOnCheckedChangeListener((bv,isChecked)->{
            Log.d("Howard","isChecked:"+isChecked);
            if (isChecked){
                sw1.setText("開");
                im1.setVisibility(View.VISIBLE);
            }else{
                sw1.setText("關");
                im1.setVisibility(View.INVISIBLE);
            }
        });

        toggleButton.setOnCheckedChangeListener((cbv,isChecked)->{
            if (isChecked){
                im2.setVisibility(View.VISIBLE);
            }else{
                im2.setVisibility(View.GONE);
            }

        });

    }
}