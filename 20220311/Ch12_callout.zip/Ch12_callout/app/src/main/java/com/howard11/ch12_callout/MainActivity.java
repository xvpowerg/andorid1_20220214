package com.howard11.ch12_callout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private String phone;
    private boolean checkCallOutPermissions(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CALL_PHONE},
                    100);
        }else{
            return true;
        }
        return false;
    }
private void callOut(String phone){
    Uri uri = Uri.parse("tel:"+phone);
    Intent phoneNumber = new Intent(Intent.ACTION_CALL,uri);
    startActivity(phoneNumber);
}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText phoneEdit = findViewById(R.id.phoneEdTxt);
        Button callOutBtn = findViewById(R.id.callOutBtn);
        callOutBtn.setOnClickListener(v->{
            phone = phoneEdit.getText().toString();
            if (checkCallOutPermissions()){

                callOut(phone);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            Log.d("Howard","onRequestPermissionsResult!!");
            callOut(phone);
        }
    }
}