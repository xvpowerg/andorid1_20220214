package com.howard11.ch6_activitylifecycle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("Howard","onCreate");
        Button btn = findViewById(R.id.button);
        btn.setOnClickListener(v->{
            Intent toPage2 = new Intent(this,Page2Activity.class);
            startActivity(toPage2);

        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("Howard","onRestart");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Howard","onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Howard","onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Howard","onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("Howard","onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy");
    }
}