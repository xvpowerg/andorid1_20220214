package com.howard11.ch6_activitylifecycle;

import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Page2Activity  extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page2_layout);
        Log.d("Howard","onCreate Page2");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Howard","onStart Page2");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Howard","onResume Page2");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Howard","onPause Page2");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("Howard","onStop Page2");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy Page2");
    }
}
//Page2