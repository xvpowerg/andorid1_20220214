package com.howard11.ch12_intentshare;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button shareBtn = findViewById(R.id.shareTxtBtn);
        Button shareImageBtn =  findViewById(R.id.shareImageBtn);
        shareBtn.setOnClickListener(v->{

            Intent  sendTextIntent = new Intent();
            sendTextIntent.setAction(Intent.ACTION_SEND);
            sendTextIntent.putExtra(Intent.EXTRA_TEXT,"Share VALUE");
            sendTextIntent.setType("text/plain");
            startActivity(sendTextIntent);

        });

        shareImageBtn.setOnClickListener(v->{
            Intent shareImageIntent = new Intent();
            Uri  uri = Uri.parse("android.resource://"+
                    getApplicationContext().getPackageName()+"/"+
                    R.drawable.image1);
            shareImageIntent.setAction(Intent.ACTION_SEND);
            shareImageIntent.putExtra(Intent.EXTRA_STREAM,uri);
            shareImageIntent.setType("image/jpg");
            startActivity(Intent.createChooser(shareImageIntent,"請選擇分享方式"));

        });
    }
}