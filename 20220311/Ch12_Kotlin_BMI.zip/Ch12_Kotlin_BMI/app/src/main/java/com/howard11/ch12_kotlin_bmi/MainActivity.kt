package com.howard11.ch12_kotlin_bmi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

const val HEIGHT_INTENT_VALUE = "height"
const val WEIGHT_INTENT_VALUE = "weight"
const val REQUEST_CODE = 100
fun TextView.toStr():String{
    return this.text.toString();
}
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

      val heightEdt =   findViewById<EditText>(R.id.heightEDT)
        val weightEdt = findViewById<EditText>(R.id.weightEDT)
        val btn = findViewById<Button>(R.id.button)
        btn.setOnClickListener {
            val heightStr = heightEdt.toStr()
            val weightStr = weightEdt.toStr()
            Log.d("Howard","$heightStr $weightStr")
              val toCalculatorBMIActivity =
                  Intent(this,CalculatorBMIActivity::class.java)
            toCalculatorBMIActivity.
            putExtra(HEIGHT_INTENT_VALUE,heightStr)
            toCalculatorBMIActivity.
            putExtra(WEIGHT_INTENT_VALUE,weightStr)
            startActivityForResult(toCalculatorBMIActivity,REQUEST_CODE)
        }
        //顯示計算後的結果
    }
}