package com.howard11.ch12_kotlin_bmi

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.howard11.ch12_kotlin_bmi.model.BmiModel

class CalculatorBMIActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val heightStr = intent.getStringExtra(HEIGHT_INTENT_VALUE)
        val weightStr =  intent.getStringExtra(WEIGHT_INTENT_VALUE)
        if (heightStr!= null && weightStr != null){
            val bmiModel = BmiModel(heightStr,weightStr)
            bmiModel.calculateBMI()
            bmiModel.getBMIStatusResID()
        }
        //結果要傳到MainActivity

    }
}