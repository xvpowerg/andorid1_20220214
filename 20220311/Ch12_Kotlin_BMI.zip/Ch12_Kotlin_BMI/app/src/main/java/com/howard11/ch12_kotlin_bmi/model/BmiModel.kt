package com.howard11.ch12_kotlin_bmi.model

import com.howard11.ch12_kotlin_bmi.R
import kotlin.math.pow

class BmiModel(var height:Double,var weight:Float) {
    private var bmi:Double = -1.0
    constructor(height:String,weight:String):this(
        height.toDouble(),weight.toFloat())
    fun  calculateBMI():Double{
            height /= 100
        bmi = weight / height.pow(2)
        return bmi
    }
    fun getBMIStatusResID():Int{

        return when{
            bmi <20 -> R.string.bmi_low
            bmi < 26 ->R.string.bmi_normal
            bmi < 40 ->R.string.bmi_moderate_obesity
            bmi < 40 ->R.string.bmi_height_obesity
            else->R.string.bmi_over_height_obesity
        }
    }

}