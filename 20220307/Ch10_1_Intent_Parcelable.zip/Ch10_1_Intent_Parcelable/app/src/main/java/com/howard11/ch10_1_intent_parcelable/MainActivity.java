package com.howard11.ch10_1_intent_parcelable;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.howard11.ch10_1_intent_parcelable.beans.UserInfo;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText nameET =  findViewById(R.id.nameET);
        EditText idET =  findViewById(R.id.identityEdit);
        EditText phoneET = findViewById(R.id.phoneET);
        EditText addressET = findViewById(R.id.addressET);

        Button submitBtn = findViewById(R.id.submitBtn);
        submitBtn.setOnClickListener(v->{
            String name = nameET.getText().toString();
            String id = idET.getText().toString();
            String phone = phoneET.getText().toString();
            String address = addressET.getText().toString();

            Intent toDetailPage = new Intent(this,DetailPageActivity.class);

//            toDetailPage.putExtra("name",name);
//            toDetailPage.putExtra("id",id);
//            toDetailPage.putExtra("phone",phone);
//            toDetailPage.putExtra("address",address);
            UserInfo userInfo =
                    new  UserInfo(name,id,phone,address);
            toDetailPage.putExtra("userInfo",userInfo);

            startActivity(toDetailPage);


        });

    }
}