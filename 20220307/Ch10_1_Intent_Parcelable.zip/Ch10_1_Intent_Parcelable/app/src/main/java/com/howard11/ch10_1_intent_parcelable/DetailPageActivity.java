package com.howard11.ch10_1_intent_parcelable;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.howard11.ch10_1_intent_parcelable.beans.UserInfo;

public class DetailPageActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.deatil_page_layout);
        String name ="";
        String id = "";
        String phone = "";
        String address = "";

        Intent data = getIntent();
        UserInfo userInfo =
                data.getParcelableExtra("userInfo");
            TextView nameTxt = findViewById(R.id.nameTxt);
            TextView idTxt = findViewById(R.id.idTxt);
            TextView phoneTxt = findViewById(R.id.phoneTxt);
            TextView addrTxt =  findViewById(R.id.addrTxt);
        nameTxt.setText(userInfo.getName());
        idTxt.setText(userInfo.getId());
        phoneTxt.setText(userInfo.getPhone());
        addrTxt.setText(userInfo.getAddress());

//        name = data.getStringExtra("name");
//        id = data.getStringExtra("id");
//        phone = data.getStringExtra("phone");
//        address = data.getStringExtra("address");

        //Log.d("Howard",name+":"+id+":"+phone+":"+address);
        Log.d("Howard",userInfo+"");

    }
}

