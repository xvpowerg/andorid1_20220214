package com.howard11.ch10_1_intent_parcelable.beans;

import android.os.Parcel;
import android.os.Parcelable;

public class UserInfo implements Parcelable {
        private String name;
        private String id;
        private String phone;
        private String address;

        public UserInfo(String name, String id, String phone, String address) {
                this.name = name;
                this.id = id;
                this.phone = phone;
                this.address = address;
        }
        public static final Parcelable.Creator<UserInfo> CREATOR =
                new Parcelable.Creator<UserInfo>(){

                        @Override
                        public UserInfo createFromParcel(Parcel source) {
                                return new UserInfo(source);
                        }

                        @Override
                        public UserInfo[] newArray(int size) {
                                return new UserInfo[size];
                        }
                };
        private UserInfo(Parcel in){
               name =  in.readString();
               id = in.readString();
               phone = in.readString();
               address = in.readString();
        }

        @Override
        public int describeContents() {
                return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
                dest.writeString(name);
                dest.writeString(id);
                dest.writeString(phone);
                dest.writeString(address);
        }

        public String getName() {
                return name;
        }

        public void setName(String name) {
                this.name = name;
        }

        public String getId() {
                return id;
        }

        public void setId(String id) {
                this.id = id;
        }

        public String getPhone() {
                return phone;
        }

        public void setPhone(String phone) {
                this.phone = phone;
        }

        public String getAddress() {
                return address;
        }

        public void setAddress(String address) {
                this.address = address;
        }

        @Override
        public String toString() {
                return "UserInfo{" +
                        "name='" + name + '\'' +
                        ", id='" + id + '\'' +
                        ", phone='" + phone + '\'' +
                        ", address='" + address + '\'' +
                        '}';
        }
}
