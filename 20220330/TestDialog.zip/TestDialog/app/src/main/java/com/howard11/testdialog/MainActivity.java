package com.howard11.testdialog;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private String fruitName = null;
    private boolean[] selected = {true,true,false};
    private ArrayList<String> names = new ArrayList<>();
    private void btn1DialogListener(DialogInterface dif,int w){
        switch (w){
            case DialogInterface.BUTTON_NEGATIVE:
                Log.d("Howard","取消");
                break;
            case DialogInterface.BUTTON_NEUTRAL:
                Log.d("Howard","關於我");
                break;
            case DialogInterface.BUTTON_POSITIVE:
                Log.d("Howard","確定");
                break;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        Button btn5 = findViewById(R.id.btn5);
        Button submit =  findViewById(R.id.submitBtn);

        btn5.setOnClickListener(v->{

            String[] array = {"雞腿","雞翅","雞胸"};

            new AlertDialog.Builder(this).
                    setMultiChoiceItems(array,selected,(d,w,s)->{
                        names.clear();
                        selected[w] = s;
                        if (s){
                            names.add(array[w]);
                              Log.d("Howard","name:"+array[w]);
                           }

                    }).setPositiveButton("確定",(d,w)->{
//                                for (int i =0 ;i < selected.length;i++){
//                                    if (selected[i]){
//                                        Log.d("Howard",array[i]);
//                                    }
//                                }
                names.forEach(n->Log.d("Howard",n));
                        }).show();
        });
        btn3.setOnClickListener(v->{
            String[]arr= new String[]{"Apple","Banana","Kiwi"};
            ArrayAdapter<String> arrayAdapter= new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    arr);

            new AlertDialog.Builder(this).setTitle("水果清單").
                   setAdapter(arrayAdapter,(d,w)->
                           {
                               fruitName = arr[w];
                               Log.d("Howard","w:"+arr[w]);
                           }
                   ).show();
        });
        submit.setOnClickListener(v->{
            if (fruitName != null){
                Log.d("Howard","fruitName:"+fruitName);
            }


        });
        btn2.setOnClickListener(v->{
            EditText editText = new EditText(this);
            editText.setHint("帳號");
            new AlertDialog.Builder(this).setTitle("請輸入帳號").
                    setMessage("帳號").
                    setView(editText).
                    setPositiveButton("確定",(b,w)->{
                        Log.d("Howard","value:"+editText.getText());

                    }).show();

        });
        btn1.setOnClickListener(v->{
            new AlertDialog.Builder(this).
                    setTitle("Title").setMessage("請輸入網址!").
                    setPositiveButton("確定",(d,w)->{
                        Log.d("Howard","確定");

                    }).
                    setNeutralButton("關於我",this::btn1DialogListener).
                    setNegativeButton("取消",this::btn1DialogListener).
                    setCancelable(false).show();



        });
    }
}