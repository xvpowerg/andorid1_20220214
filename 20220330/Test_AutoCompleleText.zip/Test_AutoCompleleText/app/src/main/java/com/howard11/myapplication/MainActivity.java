package com.howard11.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String[] images = getResources().getStringArray(R.array.images);
        ImageView imageView = findViewById(R.id.imageView);
        AutoCompleteTextView act =  findViewById(R.id.imageACT);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,android.R.id.text1,
                images);
        act.setAdapter(arrayAdapter);

        act.setOnItemClickListener((p,v,pos,id)->{
            Log.d("Howard","p:"+p);
            String name = p.getItemAtPosition(pos).toString();
            Log.d("Howard","name:"+name);

            int imageId = getResources().getIdentifier(name,"drawable",getPackageName());
            imageView.setImageResource(imageId);
        });


    }
}