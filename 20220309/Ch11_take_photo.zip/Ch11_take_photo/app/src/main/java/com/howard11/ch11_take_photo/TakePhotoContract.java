package com.howard11.ch11_take_photo;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;

import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class TakePhotoContract extends ActivityResultContract<Void, Bitmap> {
    @NonNull
    @Override
    public Intent createIntent(@NonNull Context context, Void input) {
        Intent it = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        return it;
    }

    @Override
    public Bitmap parseResult(int resultCode, @Nullable Intent intent) {

        return intent.getParcelableExtra("data");
    }
}
