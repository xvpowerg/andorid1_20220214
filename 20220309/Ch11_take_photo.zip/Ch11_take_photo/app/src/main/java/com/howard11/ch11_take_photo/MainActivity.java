package com.howard11.ch11_take_photo;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
   private  Bitmap bitmap;
    private ActivityResultLauncher<Void> launcher = registerForActivityResult(
            new TakePhotoContract(),(bmp)->{
                bitmap = bmp;
                imageView.setImageBitmap(bmp);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button photoBtn = findViewById(R.id.photoBtn);
        imageView =  findViewById(R.id.imageView);
        photoBtn.setOnClickListener(v->{
            //Intent it = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            //startActivityForResult(it,100);
            launcher.launch(null);
        });
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        bitmap =  savedInstanceState.getParcelable("bitmap");
        if (bitmap != null){
            imageView.setImageBitmap(bitmap);
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d("Howard","onSaveInstanceState");
        outState.putParcelable("bitmap",bitmap);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100){
            Log.d("Howard","showImage");
             //Bitmap bitmap = (Bitmap) data.getExtras().get("data");
           // imageView.setImageBitmap(bitmap);
        }
    }
}