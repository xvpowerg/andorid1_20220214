package com.howard11.ch11_newresult;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private ActivityResultLauncher<Intent> bmiLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    (i)->{
                        String msg = i.getData().getStringExtra("bmi_msg");
                        Log.d("Howard","registerForActivityResult:"+msg);
                    });


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText heightET = findViewById(R.id.heightET);
        EditText weightET = findViewById(R.id.weightET);
        Button btn = findViewById(R.id.submitBtn);
        btn.setOnClickListener(v->{
          String heightStr =   heightET.getText().toString();
          String weightStr =   weightET.getText().toString();
          Intent toCalculateBmi = new Intent(this,CalculateBmiActivity.class);
            toCalculateBmi.putExtra("height",heightStr);
            toCalculateBmi.putExtra("weight",weightStr);
            bmiLauncher.launch(toCalculateBmi);
        });

    }
}