package com.howard11.ch11_newresult;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CalculateBmiActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.calculate_layout);
       Intent data = getIntent();
       Button bmiBtn =  findViewById(R.id.bmiBtn);
        bmiBtn.setOnClickListener(v->{
            String heightStr = data.getStringExtra("height");
            String weightStr = data.getStringExtra("weight");

            float height = Integer.parseInt(heightStr);
            int weight = Integer.parseInt(weightStr);
            height /= 100;
            double bmi = weight /Math.pow(height,2);
            String bmiMsg = String.format("%.3f",bmi);
            Intent result = new Intent();
            result.putExtra("bmi_msg",bmiMsg);
            setResult(RESULT_OK,result);
            finish();


        });

    }
}
