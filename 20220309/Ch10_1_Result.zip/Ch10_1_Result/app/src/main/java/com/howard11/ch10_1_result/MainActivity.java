package com.howard11.ch10_1_result;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText heightEdit =  findViewById(R.id.heightET);
        EditText weightEdit =  findViewById(R.id.weightET);

        Button submitBtn =  findViewById(R.id.submitBtn);
        submitBtn.setOnClickListener(v->{
            String height = heightEdit.getText().toString();
            String weight = weightEdit.getText().toString();
            Intent  toCalIntent = new Intent(this,CalculateBmiActivity.class);
            toCalIntent.putExtra("height",height);
            toCalIntent.putExtra("weight",weight);
//            startActivity(toCalIntent);
            startActivityForResult(toCalIntent,100);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100) {
            String bmi = data.getStringExtra("bmi");
            Log.d("Howard","bmi:"+bmi);
        }
    }
}