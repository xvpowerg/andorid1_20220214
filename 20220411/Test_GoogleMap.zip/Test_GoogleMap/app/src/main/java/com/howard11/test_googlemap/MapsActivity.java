package com.howard11.test_googlemap;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.howard11.test_googlemap.databinding.ActivityMapsBinding;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        btn1.setOnClickListener(v->{
            MarkerOptions mo = new MarkerOptions();
            LatLng sydney = new LatLng( 24.13352180802151, 120.60998355796924);
            mMap.addMarker(mo.position(sydney));
            mMap.animateCamera(CameraUpdateFactory.
                    newLatLngZoom(sydney,21f),2000,null);
        });
        btn2.setOnClickListener(v->{
            LatLng latlng = new LatLng(  24.13350340376789, 120.60964896941488);
            BitmapDescriptor bd =
                    BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE);
            MarkerOptions mark = new MarkerOptions();
            mark.position(latlng);
            mark.title("雞蛋糕");
            mark.icon(bd);
            Marker markObj = mMap.addMarker(mark);
            //markObj.remove(); 可移除畫面上的點
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latlng,17));
        });
        btn3.setOnClickListener(v->{
            //GoogleMap.MAP_TYPE_HYBRID 出現衛星地圖與街道名稱
            //GoogleMap.MAP_TYPE_NONE  地圖上什麼都沒有
            //GoogleMap.MAP_TYPE_NORMAL 一般預設
            //GoogleMap.MAP_TYPE_SATELLITE 只有衛星圖
            //GoogleMap.MAP_TYPE_TERRAIN 會有地形
            mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                });

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
//        24.13352180802151, 120.60998355796924
        // Add a marker in Sydney and move the camera
//        LatLng sydney = new LatLng( 24.13352180802151, 120.60998355796924);
//        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
//        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        UiSettings uiSet =  mMap.getUiSettings();
        uiSet.setZoomControlsEnabled(true);
    }
}