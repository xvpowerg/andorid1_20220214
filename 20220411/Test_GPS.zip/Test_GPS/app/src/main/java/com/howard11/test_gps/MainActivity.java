package com.howard11.test_gps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private double lat = 22.700754264320675,lot =  120.29550030895106;
    private double tolat = 22.688934,tolot =  120.299033;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //來源 22.700754264320675, 120.29550030895106
        //目標 22.688934, 120.299033

        Button gotoBtn = findViewById(R.id.gotoBtn);
        gotoBtn.setOnClickListener(v->{
            String uri = "geo: %s,%s ?q=%s,%s";
            uri = String.format(uri,lat,lot,tolat,tolot);
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(uri)));
        });
    }
}