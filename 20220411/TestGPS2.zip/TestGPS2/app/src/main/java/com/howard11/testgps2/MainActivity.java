package com.howard11.testgps2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private LocationManager locationManager;
    private MyLocationListener myLocationListener;
    private void initGPSPermission(){
        if (ContextCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_COARSE_LOCATION) ==  PackageManager.PERMISSION_GRANTED
        ){
            addLocationChangeListener();
        }else{
            checkGPSPermission();
        }
    }
    private void checkGPSPermission(){
        ActivityCompat.requestPermissions(this,new String[]{
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
        },100);
    }

    @SuppressLint("MissingPermission")
    private void addLocationChangeListener(){
        if ( (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
            locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) ==  false){
            Intent opGps = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(opGps);
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                5000L,0f,myLocationListener);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                5000L,0f,myLocationListener);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        TextView gpsTxt = findViewById(R.id.gpstxt);
        myLocationListener = new MyLocationListener();
        myLocationListener.setChangeEven((lat,lot)->{
            String latlot = String.format("%.4f : %.4f",lat,lot);
            gpsTxt.setText(latlot);
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        initGPSPermission();
    }
}