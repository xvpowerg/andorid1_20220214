package com.howard11.testgps2;


import android.location.Location;
import android.location.LocationListener;

import androidx.annotation.NonNull;

import java.util.List;

public class MyLocationListener implements LocationListener {
    private LocationChangeEven changeEven;
        public interface  LocationChangeEven{
            void change(double lat,double lot);
        }

    public void setChangeEven(LocationChangeEven changeEven){
            this.changeEven = changeEven;
    }
    public void onLocationChanged(Location location){
        double lat = location.getLatitude();//緯度
        double log = location.getLongitude();//經度
        if (changeEven != null){
            changeEven.change(lat,log);
        }
    }

    @Override
    public void onLocationChanged(@NonNull List<Location> locations) {

    }

    @Override
    public void onFlushComplete(int requestCode) {

    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {

    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {

    }
}
