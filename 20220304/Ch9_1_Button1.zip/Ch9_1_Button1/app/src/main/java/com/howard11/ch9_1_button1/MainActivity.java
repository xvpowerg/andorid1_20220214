package com.howard11.ch9_1_button1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
    private void setImage(int imageID){
            imageView.setImageResource(imageID);
        }
        private void setImageMethod(View view){
            switch (view.getId()){
                case R.id.btn1:
                    imageView.setImageResource(R.drawable.image1);
                    break;
                case R.id.btn2:
                    imageView.setImageResource(R.drawable.image2);
                    break;
                case R.id.btn3:
                    imageView.setImageResource(R.drawable.image3);
                    break;
                case  R.id.btn4:
                    imageView.setImageResource(R.drawable.image4);
                    break;
            }
        }

      class  SetMyImage implements View.OnClickListener {
          private ImageView imageView;
          private SetMyImage(ImageView imageView){
              this.imageView = imageView;
          }
            public void  onClick(View view){
                switch(view.getId()){
                    case R.id.btn1:
                        imageView.setImageResource(R.drawable.image1);
                        break;
                    case R.id.btn2:
                        imageView.setImageResource(R.drawable.image2);
                        break;
                    case R.id.btn3:
                        imageView.setImageResource(R.drawable.image3);
                        break;
                    case R.id.btn4:
                        imageView.setImageResource(R.drawable.image4);
                        break;
                }

            }
      }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b1 = findViewById(R.id.btn1);
        Button b2 = findViewById(R.id.btn2);
        Button b3 = findViewById(R.id.btn3);
        Button b4 = findViewById(R.id.btn4);
         imageView = findViewById(R.id.imageView);
        SetMyImage setMyImage = new SetMyImage(imageView);
         b1.setOnClickListener(setMyImage);
        b2.setOnClickListener(setMyImage);
        b3.setOnClickListener(setMyImage);
        b4.setOnClickListener(setMyImage);
//        b1.setOnClickListener(this::setImageMethod);
//        b2.setOnClickListener(this::setImageMethod);
//        b3.setOnClickListener(this::setImageMethod);
//        b4.setOnClickListener(this::setImageMethod);
//        b1.setOnClickListener(v->{
//            //imageView.setImageResource(R.drawable.image1);
//            setImage(R.drawable.image1);
//        });
//        b2.setOnClickListener(v->{
//            //imageView.setImageResource(R.drawable.image2);
//            setImage(R.drawable.image2);
//        });
//        b3.setOnClickListener(v->{
//            //imageView.setImageResource(R.drawable.image3);
//            setImage(R.drawable.image3);
//
//        });

//        b4.setOnClickListener(v->{
//           // imageView.setImageResource(R.drawable.image4);
//            setImage(R.drawable.image4);
//        });

    }
}