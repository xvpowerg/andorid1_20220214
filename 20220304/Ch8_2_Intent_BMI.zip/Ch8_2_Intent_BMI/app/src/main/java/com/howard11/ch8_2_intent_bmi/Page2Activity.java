package com.howard11.ch8_2_intent_bmi;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Page2Activity  extends AppCompatActivity {

    private String getBmiStatus(float bmi){
        if (bmi >40 ){
            return  getResources().getString(R.string.bmi_status_danger);
        }else if(bmi > 30){
            return  getResources().getString(R.string.bmi_status_too_height);
        }else if(bmi > 26){
            return  getResources().getString(R.string.bmi_status_height);
        }else{
            return  getResources().getString(R.string.bmi_status_normal);
        }
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page2_layout);
        Intent data =  getIntent();
        String heightStr = data.getStringExtra("height");
        String weightStr = data.getStringExtra("weight");
        TextView heightTxt = findViewById(R.id.heightTxt);
        TextView weightTxt = findViewById(R.id.weightTxt);
        TextView statusText = findViewById(R.id.statusTxt);
        //Log.d("Howard","Height:"+height);

        heightTxt.setText(heightTxt.getText()+":"+heightStr);
        weightTxt.setText(weightTxt.getText()+":"+weightStr);
        int weight =0;
        int height =0;
        String msg = "";
        try{
             weight =  Integer.parseInt(weightStr);
        }catch(NumberFormatException ex){
            msg += "錯誤的體重";
        }
        try{
            height =  Integer.parseInt(heightStr);
        }catch(NumberFormatException ex){
            msg += "錯誤的身高";
        }



        if (msg.isEmpty()){
            float bmi = weight / (float)Math.pow(height/100f,2);
            String status =  getBmiStatus(bmi);
            statusText.setText(statusText.getText()+":"+status);
        }else{
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        }

        //BMI > 40 危險 bmi_status_danger
        //BMI > 30 過高 bmi_status_too_height
        //BMI > 26 高 bmi_status_height
        //BMI > 20 正常 bmi_status_normal
    }
}
