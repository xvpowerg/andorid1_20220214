package com.howard11.ch9_2_pagetopage;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Page2Activity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page2_layout);
        Button toPage3Btn = findViewById(R.id.toPage3Btn);
        toPage3Btn.setOnClickListener(v->{
            Intent toPage3 = new Intent(this,Page3Activity.class);
            startActivity(toPage3);

        });
    }
}
