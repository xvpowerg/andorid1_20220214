package com.howard11.ch9_2_pagetopage;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Page3Activity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page3_layout);
       Button toPage2Btn =  findViewById(R.id.toPasge2Btn);
        toPage2Btn.setOnClickListener(v->{
//            Intent toPage2 = new Intent(this,Page2Activity.class);
//            startActivity(toPage2);
            finish();

        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy!!");

    }
}
