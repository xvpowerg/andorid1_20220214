package com.howard11.test_animation;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView titleView;
        private void showDetail(View view){
            Intent toDetail = new
                    Intent(this,
                    DetailActivity.class);
            int type = 0;
            String flag = "";
            Pair<View,String> p1 = new Pair<>(titleView,getString(R.string.image_tr));
            Pair<View,String> p2 = new Pair<>(view,getString(R.string.text_tr));
            ActivityOptions aop = ActivityOptions.makeSceneTransitionAnimation(this,p1,p2);
            int imageID = -1;
            switch(view.getId()){
                case R.id.btn1:
                    imageID = R.drawable.image1;
                    break;
                case R.id.btn2:
                    imageID = R.drawable.image2;
                    break;
                case R.id.btn3:
                    imageID = R.drawable.image3;
                    break;
            }
            toDetail.putExtra("image_id",imageID);
            startActivity(toDetail,aop.toBundle());

        }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        titleView = findViewById(R.id.titleImageView);
        btn1.setOnClickListener(this::showDetail);
        btn2.setOnClickListener(this::showDetail);
        btn3.setOnClickListener(this::showDetail);
    }

}