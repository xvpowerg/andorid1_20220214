package com.howard11.test_animation;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.transition.Explode;
import android.transition.Fade;
import android.transition.Slide;
import android.transition.Transition;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {
    private  String[]imageInfos;
private void setupTransition(int imageId){
    Window window = getWindow();
    window.requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);

    Transition tr1 = new Explode();
    switch(imageId){
        case R.drawable.image1:
            tr1 = new Explode();
            break;
        case  R.drawable.image2:
            tr1 = new Slide();
            break;
            case R.drawable.image3:
            tr1 = new Fade();
                break;
    }
    tr1.setDuration(1000);
    window.setEnterTransition(tr1);
    window.setExitTransition(tr1);

}

    private String getImageInfo(int imageId){
      switch(imageId){
          case R.drawable.image1:
              return imageInfos[0];
          case R.drawable.image2:
              return imageInfos[1];
          case R.drawable.image3:
              return imageInfos[2];
      }
        return imageInfos[0];
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceStat) {
        super.onCreate(savedInstanceStat);
        Intent intent = getIntent();
        int image_id =
                intent.getIntExtra("image_id",-1);

        setupTransition(image_id);
        setContentView(R.layout.detail_layout);

        ImageView myImage = findViewById(R.id.myImage);
        TextView imageInfo =  findViewById(R.id.imageInfo);


        myImage.setImageResource(image_id);
        imageInfos = getResources().getStringArray(R.array.detail);
        imageInfo.setText(getImageInfo(image_id));

    }
}
