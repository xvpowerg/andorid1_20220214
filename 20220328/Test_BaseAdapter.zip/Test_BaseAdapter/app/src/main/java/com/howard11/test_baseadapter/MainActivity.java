package com.howard11.test_baseadapter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Person p1 = new Person("A0001","Ken",175.34f);
        Person p2 = new Person("A0002","Iris",156f);
        Person p3 = new Person("A0003","Joy",165.34f);
        Person p4 = new Person("A0004","Lucy",162f);
        Person p5 = new Person("A0005","Vivin",155f);
        ArrayList<Person> pList = new ArrayList<>();
        pList.add(p1);
        pList.add(p2);
        pList.add(p3);
        pList.add(p4);
        pList.add(p5);
        pList.add(p1);
        pList.add(p2);
        pList.add(p3);
        pList.add(p4);
        pList.add(p5);
        pList.add(p1);
        pList.add(p2);
        pList.add(p3);
        pList.add(p4);
        pList.add(p5);
        pList.add(p1);
        pList.add(p2);
        pList.add(p3);
        pList.add(p4);
        pList.add(p5);

        ListView listView = findViewById(R.id.myListVIew);
        MyBaseAdapter myBaseAdapter = new MyBaseAdapter(pList);
        listView.setAdapter(myBaseAdapter);
    }
}