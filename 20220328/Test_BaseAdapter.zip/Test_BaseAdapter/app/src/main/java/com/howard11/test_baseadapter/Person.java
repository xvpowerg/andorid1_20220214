package com.howard11.test_baseadapter;

public class Person {
    private String id;
    private String name;
    private float height;

    public Person(String id, String name, float height) {
        this.id = id;
        this.name = name;
        this.height = height;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public float getHeight() {
        return height;
    }
}
