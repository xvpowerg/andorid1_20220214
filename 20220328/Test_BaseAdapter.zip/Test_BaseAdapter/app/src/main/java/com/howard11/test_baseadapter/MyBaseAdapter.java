package com.howard11.test_baseadapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;

public class MyBaseAdapter extends BaseAdapter {
    private List<Person> data;

    public MyBaseAdapter(List<Person> data){
        this.data = data;
    }
    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Person getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        Log.d("Howard","parent:"+parent+"convertView:"+convertView);
        View view ;
        TextView idTxt,nameTxt,heightTxt;
        if (convertView!= null){
            view = convertView;
            HashMap<String,TextView> map = (HashMap)view.getTag();
            idTxt =  map.get("idTxt");
            nameTxt = map.get("nameTxt");
            heightTxt = map.get("heightTxt");
        }else{
            HashMap<String,TextView> map = new HashMap();
            view = layoutInflater.inflate(R.layout.base_adapter_layout,parent,false);
            idTxt = view.findViewById(R.id.idTxt);
            nameTxt = view.findViewById(R.id.nameTxt);
            heightTxt = view.findViewById(R.id.heightTxt);
            map.put("idTxt",idTxt);
            map.put("nameTxt",nameTxt);
            map.put("heightTxt",heightTxt);
            view.setTag(map);
        }
         Person p = getItem(position);
        idTxt.setText(p.getId());
        nameTxt.setText(p.getName());
        heightTxt.setText(p.getHeight()+"");
        return view;
    }
}

