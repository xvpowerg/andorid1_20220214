package com.howard11.test_simple_adapter2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.myListView);
        List<Map<String,Object>> data = new ArrayList<>();
        HashMap<String,Object> map1 = new HashMap<>();
        HashMap<String,Object> map2 = new HashMap<>();
        HashMap<String,Object> map3 = new HashMap<>();
        map1.put("msg","apple");
        map1.put("image",R.drawable.image1);
        map2.put("msg","cherry");
        map2.put("image",R.drawable.image2);
        map3.put("msg","kiwi");
        map3.put("image",R.drawable.image3);
        data.add(map1);
        data.add(map2);
        data.add(map3);
        String[] from = {"msg","image"};
        int[] to = {R.id.img_msg,R.id.imageView};
        SimpleAdapter simpleAdapter = new SimpleAdapter(this,data,
                R.layout.simple_adapter_layout,from,to);
        listView.setAdapter(simpleAdapter);
    }
}