package com.howard11.test_simple_adapter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView =  findViewById(R.id.myListView);
        List<Map<String,Object>> dataList = new ArrayList<>();
        Map<String,Object> map1 = new HashMap<>();
        Map<String,Object> map2 = new HashMap<>();
        Map<String,Object> map3 = new HashMap<>();

        map1.put("name","Ken");
        map1.put("score",85);
        map1.put("price",20);

        map2.put("name","Lucy");
        map2.put("score",77);
        map2.put("price",15);

        map3.put("name","Iris");
        map3.put("score",92);
        map3.put("price",27);

        dataList.add(map1);
        dataList.add(map2);
        dataList.add(map3);
        /*
       SimpleAdapter(Context context, List<? extends Map<String, ?>> data,
            @LayoutRes int resource, String[] from, @IdRes int[] to)
         */
        String[] from = {"name","score","price"};
        int[] to = {R.id.nameTxt,R.id.scoreTxt,R.id.priceTxt};
        SimpleAdapter simpleAdapter = new SimpleAdapter(this,
                dataList,
                R.layout.simple_adapter_layout,from,to);
        listView.setAdapter(simpleAdapter);

        listView.setOnItemClickListener((p,v,pos,id)->{
            Map<String,Object> map = dataList.get(pos);
            Log.d("Howard",
                    map.get("name")+":"+map.get("score")+":"+  map.get("price"));

        });
    }
}