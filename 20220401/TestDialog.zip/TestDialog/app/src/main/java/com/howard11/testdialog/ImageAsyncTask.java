package com.howard11.testdialog;

import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

public class ImageAsyncTask extends AsyncTask<String,Void, Bitmap> {
    private AlertDialog dialog;
    private ProgressBar pb;
    private ImageView imageView;
    public ImageAsyncTask(AlertDialog dialog,
                          ProgressBar pb,
                          ImageView imageView){
            this.dialog = dialog;
            this.pb = pb;
            this.imageView = imageView;
    }
    //ImageAsyncTask 執行之前呼叫
    @Override
    protected void onPreExecute() {
        pb.setVisibility(View.VISIBLE);
    }
    //ImageAsyncTask 執行中呼叫
    @Override
    protected Bitmap doInBackground(String... strings) {
        String url = strings[0];
        Bitmap bitmap = ImageTool.getImage(url);
        Log.d("Howard","Thread name:"+Thread.currentThread().getName());
        return bitmap;
    }
    //ImageAsyncTask 執行完畢後呼叫
    @Override
    protected void onPostExecute(Bitmap bitmap) {
       if (bitmap!= null){
           imageView.setImageBitmap(bitmap);
       }
       pb.setVisibility(View.INVISIBLE);
       dialog.dismiss();
    }
}
