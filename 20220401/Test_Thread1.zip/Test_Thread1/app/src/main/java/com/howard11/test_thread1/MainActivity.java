package com.howard11.test_thread1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.time.LocalTime;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
        private boolean canRun = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button startBtn = findViewById(R.id.startBtn);
        Button stopBtn =   findViewById(R.id.stopBtn);
        stopBtn.setOnClickListener(v->{
            canRun = false;
        });
        TextView timeView = findViewById(R.id.textView);
        startBtn.setOnClickListener(v->{
            canRun = true;
            Thread th1 = new Thread(()->{
                while(canRun){
                    LocalTime localTime = LocalTime.now();
                    String time =  String.format("%02d:%02d:%02d",localTime.getHour(),
                            localTime.getMinute(),
                            localTime.getSecond());
                    timeView.setText(time);
                    try{
                        TimeUnit.SECONDS.sleep(1);
                    }catch(InterruptedException ex){

                    }

                }


            });
            th1.start();


        });
    }
}